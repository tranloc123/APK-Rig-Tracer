package com.tranloc.apkrigtracer

data class BoneSnapshot(
    val name: String,
    val pathId: Long,
    val parentIndex: Int,
    val tx: Float, val ty: Float, val tz: Float,
    val qx: Float, val qy: Float, val qz: Float, val qw: Float,
    val sx: Float, val sy: Float, val sz: Float,
    val inverseBind: FloatArray
)

data class RigSnapshot(
    val name: String,
    val source: String,
    val vertices: FloatArray,
    val normals: FloatArray,
    val indices: IntArray,
    val boneIndices: IntArray,
    val boneWeights: FloatArray,
    val bones: List<BoneSnapshot>,
    val avatarName: String?,
    val animationCount: Int,
    val warnings: List<String> = emptyList(),
    val kind: String = "MODEL"
) {
    val vertexCount: Int get() = vertices.size / 3
    val boneCount: Int get() = bones.size
    val isRigged: Boolean
        get() = bones.isNotEmpty() && boneIndices.size >= vertexCount * 4 && boneWeights.size >= vertexCount * 4
    val status: String get() = when {
        isRigged -> "MODEL COMPLETE"
        vertexCount > 0 -> "MODEL MISSING RIG"
        bones.isNotEmpty() -> "RIG MISSING MESH"
        else -> "UNKNOWN"
    }
}

data class ScanSummary(
    val engine: String,
    val filesScanned: Int,
    val bytesScanned: Long,
    val unityCandidates: Int,
    val findings: List<ArtifactFinding>,
    val engineScores: Map<String, Int>,
    val highEntropyFiles: Int,
    val embeddedContainers: Int,
    val unityInventory: Map<String, Int>,
    val warnings: List<String>,
    val rigs: List<RigSnapshot>
)

object SessionStore {
    @Volatile var selectedRig: RigSnapshot? = null
}
