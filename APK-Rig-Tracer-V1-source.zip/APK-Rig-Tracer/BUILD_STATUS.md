# V2 build status

## Implemented
- [x] V1 narrow extension filter removed
- [x] Universal byte-signature scanner
- [x] Every copied file scanned in chunks, no 60k-file cap
- [x] ZIP/APK recursive extraction by magic
- [x] Embedded ZIP extraction
- [x] PE/EXE + ELF recognition
- [x] PE overlay reporting
- [x] Embedded UnityFS/UnityRaw/UnityWeb discovery and bounded carving
- [x] Unity SerializedFile header heuristic
- [x] Unreal/Godot container/signature indexing
- [x] Direct GLB/FBX/model/media signatures
- [x] High-entropy diagnostic
- [x] Raw float32 geometry heuristic (low confidence)
- [x] Unity object inventory
- [x] Standalone Unity Mesh listing
- [x] Unity rig tracing + hash-path fallback attempt
- [x] Static mesh GLB export
- [x] Rigged mesh GLB export
- [x] Preview remains compatible with static and rigged models
- [x] In-app Universal Scan Report
- [x] Cancellation checks throughout scanning/extraction
- [x] ZIP path traversal / extraction limits
- [x] Pure Kotlin UniversalScanner compile check
- [x] Synthetic recursive ZIP + PE + embedded UnityFS scanner test

## Still requires Android CI/device validation
- [ ] Full Android Gradle compile (local runtime has no Android SDK)
- [ ] UnityKt/JitPack resolution in Android CI
- [ ] Physical-device run on ROG Phone 6
- [ ] Real Unity APK/EXE corpus validation
- [ ] Deep Unreal/Godot/Cocos model/rig adapters
