package com.tranloc.apkrigtracer

import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class PreviewActivity: AppCompatActivity() {
    private lateinit var preview: RigPreviewView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val rig=SessionStore.selectedRig ?: run { finish(); return }
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(8,8,8,8)}
        val title=TextView(this).apply{text="${rig.name} • ${rig.boneCount} bones • ${rig.vertexCount} vertices";textSize=16f;setPadding(8,8,8,8)}
        preview=RigPreviewView(this,rig);root.addView(title);root.addView(preview,LinearLayout.LayoutParams(-1,0,1f))
        val row1=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL};val row2=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        fun add(row:LinearLayout,label:String,pose:TestPose){row.addView(Button(this).apply{text=label;setOnClickListener{preview.setPose(pose)}},LinearLayout.LayoutParams(0,-2,1f))}
        add(row1,"Bind",TestPose.BIND);add(row1,"T-Pose",TestPose.T_POSE);add(row1,"Chào",TestPose.WAVE)
        add(row2,"Nhảy",TestPose.JUMP);add(row2,"Ngồi xổm",TestPose.SQUAT);add(row2,"Hiphop",TestPose.HIPHOP)
        root.addView(row1);root.addView(row2);setContentView(root)
        val gd=GestureDetector(this,object:GestureDetector.SimpleOnGestureListener(){override fun onDown(e:MotionEvent)=true;override fun onScroll(e1:MotionEvent?,e2:MotionEvent,dX:Float,dY:Float):Boolean{preview.rotateBy(-dX*0.25f);return true}})
        preview.setOnTouchListener{_,e->gd.onTouchEvent(e)}
    }
    override fun onResume(){super.onResume();preview.onResume()}
    override fun onPause(){preview.onPause();super.onPause()}
}
