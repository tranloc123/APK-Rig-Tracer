# Universal Game Asset Tracer V2

Android-first universal discovery + Unity deep tracer for game files the user is authorized to inspect.

## V2 core rewrite

V2 no longer decides what to scan from the filename. Every materialized file is scanned byte-by-byte in chunks for known container/model/media signatures.

### Inputs
- Any single file: APK, EXE, DLL, BIN, OBB, PAK, bundle, no-extension files, etc.
- Any user-selected folder through Android Storage Access Framework.

### Universal discovery
- Recursive ZIP/APK/XAPK/APKS-style container extraction based on ZIP magic, not extension.
- Embedded ZIP discovery and extraction.
- PE/MZ and ELF executable recognition; PE overlay reporting.
- Embedded `UnityFS`, `UnityRaw`, and `UnityWeb` signature discovery.
- Unity SerializedFile header heuristic independent of extension.
- Unreal `.pak` footer magic / IoStore signature hints.
- Godot PCK (`GDPC`) recognition.
- Direct model/media signatures: GLB, FBX binary, PNG, JPEG, DDS, KTX/KTX2, OGG.
- GZIP, 7z, LZ4-frame, Zstandard-frame recognition.
- High-entropy reporting for data likely compressed/encrypted/media.
- Low-confidence float32 geometry heuristic for otherwise unknown binaries.

### Unity deep tracing
- Loads every Unity candidate that the Unity parser accepts.
- Object inventory is always reported, even if no model/rig pair is reconstructed.
- Exposes standalone Mesh objects instead of hiding meshes without rigs.
- SkinnedMeshRenderer -> Mesh -> Transform/bones -> Animator/Avatar tracing.
- `m_Bones` first, then best-effort `m_BoneNameHashes` / transform-path CRC32 fallback.
- CPU skinning and procedural test poses: T-pose, wave, jump, squat, hip-hop.
- GLB export for both static meshes and rigged meshes.

## What V2 does not pretend to do
- Unreal/Godot/Cocos deep model reconstruction is not implemented yet; V2 detects/indexes their containers so they are not silently skipped.
- It does not bypass DRM, obtain encryption keys, bypass anti-cheat, or decrypt proprietary encrypted asset stores.
- Android 11+ may block direct access to another app's private `Android/data` / `Android/obb`; select accessible copies/files with SAF.
- Server-only assets cannot be scanned until they exist in an accessible local file.

## Build
The included GitHub Actions workflow builds `app-debug.apk` and uploads it as `APK-Rig-Tracer-V2-debug`.
