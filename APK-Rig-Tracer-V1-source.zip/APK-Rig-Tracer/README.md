# APK Rig Tracer V1
Android tool for inspecting Unity game containers you are authorized to analyze.

## V1 scope
- Import APK / XAPK / APKS / OBB / Unity bundle / directory using Android SAF.
- Safe extraction with path traversal, entry count and expanded-size limits.
- Detect Unity / Unreal / Godot indicators.
- Unity rig tracing: SkinnedMeshRenderer -> Mesh -> bones -> GameObject -> Animator/Avatar.
- Rig list and relationship report.
- Minimal GLB export: geometry + JOINTS_0 + WEIGHTS_0 + skeleton + inverse bind matrices.
- Preview screen with skeleton and procedural rig poses: T-pose, wave, jump, squat, hip-hop.

## Limits
- Does not bypass DRM/encryption or Android private app storage.
- Server-downloaded assets must be supplied by the user if they are not in the APK/container.
- V1 parses Unity only. Other engines are detected and reported.
- Texture/material export is intentionally deferred until mesh+rig correctness is proven.

## Build
GitHub Actions builds `app-debug.apk` and uploads it as `APK-Rig-Tracer-debug`.
