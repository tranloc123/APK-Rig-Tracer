package com.tranloc.apkrigtracer

import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque
import java.util.Locale
import java.util.concurrent.CancellationException
import java.util.zip.ZipInputStream
import kotlin.math.ln

/**
 * V2 discovery layer. It scans every byte of every materialized file in chunks and
 * does not trust file extensions. Extensions are only secondary hints.
 */
object UniversalScanner {
    private data class Sig(val type: String, val bytes: ByteArray, val confidence: Int, val engine: String? = null)

    private val signatures = listOf(
        Sig("UNITY_BUNDLE", "UnityFS\u0000".toByteArray(Charsets.ISO_8859_1), 100, "Unity"),
        Sig("UNITY_BUNDLE", "UnityRaw\u0000".toByteArray(Charsets.ISO_8859_1), 100, "Unity"),
        Sig("UNITY_BUNDLE", "UnityWeb\u0000".toByteArray(Charsets.ISO_8859_1), 100, "Unity"),
        Sig("GLB", byteArrayOf(0x67, 0x6C, 0x54, 0x46), 100),
        Sig("FBX_BINARY", "Kaydara FBX Binary".toByteArray(Charsets.US_ASCII), 100),
        Sig("PMX_MODEL", "PMX ".toByteArray(Charsets.US_ASCII), 100),
        Sig("PMD_MODEL", "Pmd".toByteArray(Charsets.US_ASCII), 95),
        Sig("PNG", byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A), 100),
        Sig("JPEG", byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte()), 95),
        Sig("DDS", "DDS ".toByteArray(Charsets.US_ASCII), 100),
        Sig("KTX", byteArrayOf(0xAB.toByte(), 0x4B, 0x54, 0x58, 0x20, 0x31, 0x31, 0xBB.toByte(), 0x0D, 0x0A, 0x1A, 0x0A), 100),
        Sig("KTX2", byteArrayOf(0xAB.toByte(), 0x4B, 0x54, 0x58, 0x20, 0x32, 0x30, 0xBB.toByte(), 0x0D, 0x0A, 0x1A, 0x0A), 100),
        Sig("OGG", "OggS".toByteArray(Charsets.US_ASCII), 100),
        Sig("GODOT_PCK", "GDPC".toByteArray(Charsets.US_ASCII), 95, "Godot"),
        Sig("ZIP", byteArrayOf(0x50, 0x4B, 0x03, 0x04), 100),
        Sig("GZIP", byteArrayOf(0x1F, 0x8B.toByte(), 0x08), 95),
        Sig("7Z", byteArrayOf(0x37, 0x7A, 0xBC.toByte(), 0xAF.toByte(), 0x27, 0x1C), 100),
        Sig("RAR4", byteArrayOf(0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x00), 100),
        Sig("RAR5", byteArrayOf(0x52, 0x61, 0x72, 0x21, 0x1A, 0x07, 0x01, 0x00), 100),
        Sig("MS_CAB", "MSCF".toByteArray(Charsets.US_ASCII), 100),
        Sig("BZIP2", "BZh".toByteArray(Charsets.US_ASCII), 95),
        Sig("XZ", byteArrayOf(0xFD.toByte(), 0x37, 0x7A, 0x58, 0x5A, 0x00), 100),
        Sig("LZ4_FRAME", byteArrayOf(0x04, 0x22, 0x4D, 0x18), 95),
        Sig("ZSTD_FRAME", byteArrayOf(0x28, 0xB5.toByte(), 0x2F, 0xFD.toByte()), 95),
        Sig("UNREAL_PAK_MAGIC", byteArrayOf(0xE1.toByte(), 0x12, 0x6F, 0x5A), 70, "Unreal"),
        Sig("UNREAL_IOSTORE_MAGIC", "-==--==--==--==-".toByteArray(Charsets.US_ASCII), 85, "Unreal")
    )

    private const val CHUNK = 1024 * 1024
    private const val MAX_FINDINGS = 20_000
    private const val MAX_PER_SIG_PER_FILE = 6
    private const val MAX_CARVE_BYTES = 768L * 1024 * 1024
    private const val MAX_EMBEDDED_ZIP_ENTRIES = 25_000
    private const val MAX_EMBEDDED_ZIP_BYTES = 3L * 1024 * 1024 * 1024

    fun scan(root: File, cancelled: () -> Boolean = { false }): UniversalScanResult {
        val warnings = mutableListOf<String>()
        val findings = mutableListOf<ArtifactFinding>()
        val unityCandidates = LinkedHashMap<String, File>()
        val engineScores = linkedMapOf("Unity" to 0, "Unreal" to 0, "Godot" to 0, "Cocos" to 0)
        val queue = ArrayDeque<File>()
        val seen = HashSet<String>()
        val carveRoot = File(root, ".universal_carved").apply { mkdirs() }

        root.walkTopDown()
            .filter { it.isFile && !it.path.contains(File.separator + ".universal_carved" + File.separator) }
            .forEach { queue.add(it) }

        var filesScanned = 0
        var bytesScanned = 0L
        var highEntropyFiles = 0
        var embeddedContainers = 0

        while (queue.isNotEmpty()) {
            checkCancelled(cancelled)
            val file = queue.removeFirst()
            val canonical = runCatching { file.canonicalPath }.getOrElse { file.absolutePath }
            if (!seen.add(canonical) || !file.isFile) continue
            filesScanned++
            bytesScanned += file.length()

            val local = scanFile(file, cancelled)
            local.findings.forEach { f ->
                if (findings.size < MAX_FINDINGS) findings += f
                when (f.type) {
                    "UNITY_BUNDLE", "UNITY_SERIALIZED" -> engineScores["Unity"] = engineScores.getValue("Unity") + if (f.confidence >= 90) 5 else 2
                    "UNREAL_PAK_MAGIC", "UNREAL_IOSTORE_MAGIC" -> engineScores["Unreal"] = engineScores.getValue("Unreal") + 3
                    "GODOT_PCK" -> engineScores["Godot"] = engineScores.getValue("Godot") + 4
                    "COCOS_ASSET_HINT" -> engineScores["Cocos"] = engineScores.getValue("Cocos") + 2
                }
            }
            if (local.highEntropy) highEntropyFiles++

            if (local.unitySerializedAtZero) unityCandidates[canonical] = file
            for (hit in local.signatureHits.filter { it.sig.type == "UNITY_BUNDLE" }) {
                if (hit.offset == 0L) {
                    unityCandidates[canonical] = file
                } else {
                    embeddedContainers++
                    val carved = carveUnityBundle(file, hit.offset, carveRoot, warnings, cancelled)
                    if (carved != null) {
                        unityCandidates[runCatching { carved.canonicalPath }.getOrElse { carved.absolutePath }] = carved
                        queue.add(carved)
                    }
                }
            }

            val zipHits = local.signatureHits.filter { it.sig.type == "ZIP" }
                .let { list -> if (list.any { it.offset == 0L }) listOf(list.first { it.offset == 0L }) else list.take(2) }
            for (hit in zipHits) {
                if (hit.offset > 0L) embeddedContainers++
                val out = File(carveRoot, "zip_${safeId(file)}_${hit.offset.toString(16)}").apply { mkdirs() }
                val extracted = extractEmbeddedZip(file, hit.offset, out, warnings, cancelled)
                extracted.forEach { queue.add(it) }
            }

            addExtensionHints(file, findings, engineScores)
            if (findings.size < MAX_FINDINGS && local.geometryHint != null) findings += local.geometryHint
        }

        if (findings.size >= MAX_FINDINGS) warnings += "Danh sách kết quả đã chạm giới hạn $MAX_FINDINGS mục; quá trình quét byte vẫn tiếp tục."
        if (highEntropyFiles > 0) warnings += "$highEntropyFiles file có entropy cao; chúng có thể là dữ liệu nén, mã hóa hoặc media."
        if (unityCandidates.isEmpty() && engineScores.getValue("Unity") > 0) {
            warnings += "Có dấu hiệu Unity nhưng chưa tạo được Unity deep-parse candidate."
        }

        return UniversalScanResult(
            filesScanned = filesScanned,
            bytesScanned = bytesScanned,
            findings = findings.distinctBy { Triple(it.filePath, it.type, it.offset) },
            unityCandidates = unityCandidates.values.toList(),
            engineScores = engineScores,
            highEntropyFiles = highEntropyFiles,
            embeddedContainers = embeddedContainers,
            warnings = warnings.distinct()
        )
    }

    private data class Hit(val sig: Sig, val offset: Long)
    private data class LocalScan(
        val findings: List<ArtifactFinding>,
        val signatureHits: List<Hit>,
        val highEntropy: Boolean,
        val unitySerializedAtZero: Boolean,
        val geometryHint: ArtifactFinding?
    )

    private fun scanFile(file: File, cancelled: () -> Boolean): LocalScan {
        val out = mutableListOf<ArtifactFinding>()
        val hits = mutableListOf<Hit>()
        val perSig = HashMap<String, Int>()
        val maxSig = signatures.maxOf { it.bytes.size }
        val overlap = ByteArray(maxSig - 1)
        var overlapLen = 0
        var absolute = 0L

        val sample = ByteArrayOutputCollector(1024 * 1024)
        file.inputStream().buffered(CHUNK).use { input ->
            val buf = ByteArray(CHUNK)
            while (true) {
                checkCancelled(cancelled)
                val n = input.read(buf)
                if (n <= 0) break
                if (sample.size < sample.capacity) sample.append(buf, 0, minOf(n, sample.capacity - sample.size))

                val combined = ByteArray(overlapLen + n)
                if (overlapLen > 0) System.arraycopy(overlap, 0, combined, 0, overlapLen)
                System.arraycopy(buf, 0, combined, overlapLen, n)
                val baseOffset = absolute - overlapLen

                for (sig in signatures) {
                    var from = 0
                    while (from <= combined.size - sig.bytes.size) {
                        val idx = indexOf(combined, sig.bytes, from)
                        if (idx < 0) break
                        val off = baseOffset + idx
                        val count = perSig[sig.type] ?: 0
                        if (count < MAX_PER_SIG_PER_FILE) {
                            hits += Hit(sig, off)
                            out += ArtifactFinding(
                                filePath = file.absolutePath,
                                type = sig.type,
                                offset = off,
                                confidence = sig.confidence,
                                detail = if (off == 0L) "header" else "embedded signature",
                                embedded = off > 0L
                            )
                            perSig[sig.type] = count + 1
                        }
                        from = idx + 1
                    }
                }

                overlapLen = minOf(overlap.size, combined.size)
                if (overlapLen > 0) System.arraycopy(combined, combined.size - overlapLen, overlap, 0, overlapLen)
                absolute += n
            }
        }

        detectExecutable(file)?.let { out += it }
        val serialized = looksLikeUnitySerialized(file)
        if (serialized) out += ArtifactFinding(file.absolutePath, "UNITY_SERIALIZED", 0, 85, "serialized-file header heuristic")
        val sampleBytes = sample.bytes()
        detectTextModelHeaders(file, sampleBytes).forEach { out += it }
        val entropy = entropy(sampleBytes)
        val highEntropy = sample.size >= 4096 && entropy >= 7.75
        if (highEntropy) out += ArtifactFinding(file.absolutePath, "HIGH_ENTROPY", 0, 55, "sample entropy ${"%.2f".format(Locale.US, entropy)} bits/byte")
        val geometry = if (out.none { it.type in knownAssetTypes }) rawGeometryHint(file) else null
        return LocalScan(out, hits, highEntropy, serialized, geometry)
    }

    private val knownAssetTypes = setOf(
        "UNITY_BUNDLE", "UNITY_SERIALIZED", "GLB", "GLTF_JSON", "FBX_BINARY", "FBX_ASCII", "OBJ_TEXT", "COLLADA", "BVH", "PMX_MODEL", "PMD_MODEL",
        "PNG", "JPEG", "DDS", "KTX", "KTX2", "GODOT_PCK", "UNREAL_PAK_MAGIC", "UNREAL_IOSTORE_MAGIC"
    )


    private fun detectTextModelHeaders(file: File, bytes: ByteArray): List<ArtifactFinding> {
        if (bytes.isEmpty()) return emptyList()
        val limit = minOf(bytes.size, 512 * 1024)
        val text = runCatching { String(bytes, 0, limit, Charsets.UTF_8) }.getOrDefault("")
        if (text.isBlank()) return emptyList()
        val trimmed = text.trimStart()
        val out = mutableListOf<ArtifactFinding>()
        fun add(type: String, confidence: Int, detail: String) {
            out += ArtifactFinding(file.absolutePath, type, 0, confidence, detail)
        }
        if (trimmed.startsWith("HIERARCHY") && text.contains("MOTION")) add("BVH", 95, "BVH hierarchy/motion text")
        if (text.contains("<COLLADA", ignoreCase = true)) add("COLLADA", 95, "COLLADA XML")
        if (trimmed.startsWith("; FBX") || text.contains("FBXHeaderExtension")) add("FBX_ASCII", 90, "ASCII FBX")
        if (trimmed.startsWith("{") && text.contains("\"asset\"") && text.contains("\"version\"") &&
            (text.contains("\"meshes\"") || text.contains("\"skins\""))) {
            add("GLTF_JSON", 92, "glTF JSON structure")
        }
        var objV = 0
        var objF = 0
        text.lineSequence().take(20_000).forEach { line ->
            val t = line.trimStart()
            if (t.startsWith("v ")) objV++
            else if (t.startsWith("f ")) objF++
        }
        if (objV >= 3 && objF >= 1) add("OBJ_TEXT", 85, "OBJ-like vertices=$objV faces=$objF")
        if (text.contains("cc.Mesh") || text.contains("cc.Skeleton") || text.contains("cc.SkeletalAnimation")) {
            add("COCOS_ASSET_HINT", 65, "Cocos Creator class names")
        }
        return out
    }

    private fun detectExecutable(file: File): ArtifactFinding? = runCatching {
        if (file.length() < 64) return@runCatching null
        RandomAccessFile(file, "r").use { raf ->
            val b = ByteArray(64)
            raf.readFully(b)
            if (b[0] == 'M'.code.toByte() && b[1] == 'Z'.code.toByte()) {
                val peOff = ByteBuffer.wrap(b, 0x3C, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xffffffffL
                if (peOff + 24 <= file.length()) {
                    raf.seek(peOff)
                    val sig = ByteArray(4); raf.readFully(sig)
                    if (sig.contentEquals(byteArrayOf('P'.code.toByte(), 'E'.code.toByte(), 0, 0))) {
                        val overlay = peOverlayOffset(raf, peOff, file.length())
                        return@use ArtifactFinding(file.absolutePath, "PE_EXECUTABLE", 0, 100,
                            if (overlay != null) "PE; overlay starts @ 0x${overlay.toString(16)}" else "PE")
                    }
                }
                return@use ArtifactFinding(file.absolutePath, "MZ_EXECUTABLE", 0, 80, "MZ header")
            }
            if (b[0] == 0x7F.toByte() && b[1] == 'E'.code.toByte() && b[2] == 'L'.code.toByte() && b[3] == 'F'.code.toByte()) {
                return@use ArtifactFinding(file.absolutePath, "ELF_EXECUTABLE", 0, 100, "ELF${if (b[4].toInt() == 2) "64" else "32"}")
            }
            null
        }
    }.getOrNull()

    private fun peOverlayOffset(raf: RandomAccessFile, peOff: Long, fileLen: Long): Long? = runCatching {
        raf.seek(peOff + 4)
        val coff = ByteArray(20); raf.readFully(coff)
        val bb = ByteBuffer.wrap(coff).order(ByteOrder.LITTLE_ENDIAN)
        bb.short // machine
        val sectionCount = bb.short.toInt() and 0xffff
        bb.position(16)
        val optionalSize = bb.short.toInt() and 0xffff
        val sectionStart = peOff + 4 + 20 + optionalSize
        var end = 0L
        for (i in 0 until sectionCount) {
            raf.seek(sectionStart + i * 40L + 16)
            val tmp = ByteArray(8); raf.readFully(tmp)
            val s = ByteBuffer.wrap(tmp).order(ByteOrder.LITTLE_ENDIAN)
            val rawSize = s.int.toLong() and 0xffffffffL
            val rawPtr = s.int.toLong() and 0xffffffffL
            end = maxOf(end, rawPtr + rawSize)
        }
        end.takeIf { it in 1 until fileLen }
    }.getOrNull()

    private fun looksLikeUnitySerialized(file: File): Boolean = runCatching {
        if (file.length() < 32) return@runCatching false
        val b = ByteArray(32)
        file.inputStream().use { if (it.read(b) < 20) return@runCatching false }
        val bb = ByteBuffer.wrap(b).order(ByteOrder.BIG_ENDIAN)
        val metadata = bb.int.toLong() and 0xffffffffL
        val fileSize32 = bb.int.toLong() and 0xffffffffL
        val version = bb.int
        val dataOffset = bb.int.toLong() and 0xffffffffL
        val len = file.length()
        val metadataOk = metadata in 16..(128L * 1024 * 1024)
        val versionOk = version in 5..40
        val dataOk = dataOffset in 16..len
        val sizeOk = fileSize32 == len || (version >= 22 && fileSize32 <= len) || (fileSize32 in dataOffset..len)
        metadataOk && versionOk && dataOk && sizeOk
    }.getOrDefault(false)

    private fun addExtensionHints(file: File, findings: MutableList<ArtifactFinding>, scores: MutableMap<String, Int>) {
        if (findings.size >= MAX_FINDINGS) return
        val n = file.name.lowercase(Locale.ROOT)
        fun add(type: String, engine: String? = null, detail: String = "extension/path hint") {
            findings += ArtifactFinding(file.absolutePath, type, 0, 35, detail)
            if (engine != null) scores[engine] = (scores[engine] ?: 0) + 1
        }
        when {
            n.endsWith(".uasset") || n.endsWith(".uexp") || n.endsWith(".ubulk") || n.endsWith(".pak") || n.endsWith(".utoc") || n.endsWith(".ucas") -> add("UNREAL_FILE_HINT", "Unreal")
            n.endsWith(".pck") -> add("GODOT_FILE_HINT", "Godot")
            n.endsWith(".assets") || n.endsWith(".ress") || n.endsWith(".resource") || n == "globalgamemanagers" || n == "resources.assets" -> add("UNITY_FILE_HINT", "Unity")
            n.endsWith(".mesh") || n.endsWith(".skeleton") || n.endsWith(".anim") -> add("GAME_ASSET_HINT")
            n.endsWith(".gltf") || n.endsWith(".obj") || n.endsWith(".dae") || n.endsWith(".pmx") || n.endsWith(".pmd") -> add("MODEL_FILE_HINT")
        }
    }

    private fun rawGeometryHint(file: File): ArtifactFinding? = runCatching {
        if (file.length() !in 64L * 1024..128L * 1024 * 1024) return@runCatching null
        val sampleSize = minOf(file.length(), 2L * 1024 * 1024).toInt()
        val b = ByteArray(sampleSize)
        file.inputStream().use { if (it.read(b) < 4096) return@runCatching null }
        val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
        val floats = b.size / 4
        if (floats < 4096) return@runCatching null
        var finiteReasonable = 0
        var nonZero = 0
        var triples = 0
        var plausibleTriples = 0
        val limit = minOf(floats, 250_000)
        val vals = FloatArray(limit)
        for (i in 0 until limit) {
            val v = bb.float
            vals[i] = v
            if (v.isFinite() && kotlin.math.abs(v) < 1_000_000f) finiteReasonable++
            if (v.isFinite() && kotlin.math.abs(v) > 1e-7f && kotlin.math.abs(v) < 100_000f) nonZero++
        }
        var i = 0
        while (i + 2 < limit) {
            triples++
            val x = vals[i]; val y = vals[i + 1]; val z = vals[i + 2]
            if (x.isFinite() && y.isFinite() && z.isFinite() &&
                kotlin.math.abs(x) < 100_000f && kotlin.math.abs(y) < 100_000f && kotlin.math.abs(z) < 100_000f &&
                (kotlin.math.abs(x) + kotlin.math.abs(y) + kotlin.math.abs(z)) > 1e-5f) plausibleTriples++
            i += 3
        }
        val finiteRatio = finiteReasonable.toDouble() / limit
        val nonZeroRatio = nonZero.toDouble() / limit
        val tripleRatio = if (triples == 0) 0.0 else plausibleTriples.toDouble() / triples
        if (finiteRatio > 0.94 && nonZeroRatio > 0.35 && tripleRatio > 0.75) {
            ArtifactFinding(file.absolutePath, "POSSIBLE_RAW_GEOMETRY", 0, 45,
                "float32 heuristic; finite=${pct(finiteRatio)}, xyz=${pct(tripleRatio)}")
        } else null
    }.getOrNull()

    private fun pct(v: Double) = "%.0f%%".format(Locale.US, v * 100.0)

    private fun entropy(bytes: ByteArray): Double {
        if (bytes.isEmpty()) return 0.0
        val counts = IntArray(256)
        for (b in bytes) counts[b.toInt() and 0xff]++
        var h = 0.0
        val n = bytes.size.toDouble()
        for (c in counts) if (c > 0) {
            val p = c / n
            h -= p * (ln(p) / ln(2.0))
        }
        return h
    }

    private fun carveUnityBundle(
        source: File,
        offset: Long,
        carveRoot: File,
        warnings: MutableList<String>,
        cancelled: () -> Boolean
    ): File? = runCatching {
        val len = unityBundleLength(source, offset) ?: return@runCatching null
        if (len <= 0 || offset + len > source.length()) return@runCatching null
        if (len > MAX_CARVE_BYTES) {
            warnings += "Unity bundle nhúng ${source.name}@0x${offset.toString(16)} dài ${human(len)}; đã nhận diện nhưng không carve để tránh nhân đôi bộ nhớ."
            return@runCatching null
        }
        val out = File(carveRoot, "unity_${safeId(source)}_${offset.toString(16)}.bundle")
        RandomAccessFile(source, "r").use { raf ->
            raf.seek(offset)
            FileOutputStream(out).use { fos ->
                val buf = ByteArray(CHUNK)
                var remaining = len
                while (remaining > 0) {
                    checkCancelled(cancelled)
                    val n = raf.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                    if (n <= 0) break
                    fos.write(buf, 0, n)
                    remaining -= n
                }
                if (remaining != 0L) error("carve thiếu ${human(remaining)}")
            }
        }
        out
    }.onFailure { warnings += "Không carve được Unity bundle trong ${source.name}: ${it.message}" }.getOrNull()

    private fun unityBundleLength(file: File, offset: Long): Long? = runCatching {
        RandomAccessFile(file, "r").use { raf ->
            raf.seek(offset)
            val sig = readCString(raf, 32)
            if (sig !in setOf("UnityFS", "UnityRaw", "UnityWeb")) return@use null
            val version = raf.readInt()
            if (version !in 1..20) return@use null
            readCString(raf, 128)
            readCString(raf, 128)
            val size = raf.readLong()
            size.takeIf { it > 0 && it <= file.length() - offset }
        }
    }.getOrNull()

    private fun readCString(raf: RandomAccessFile, max: Int): String {
        val out = ByteArray(max)
        var n = 0
        while (n < max) {
            val b = raf.read()
            if (b < 0 || b == 0) break
            out[n++] = b.toByte()
        }
        return String(out, 0, n, Charsets.ISO_8859_1)
    }

    private fun extractEmbeddedZip(
        source: File,
        offset: Long,
        outDir: File,
        warnings: MutableList<String>,
        cancelled: () -> Boolean
    ): List<File> {
        val extracted = mutableListOf<File>()
        return runCatching {
            val root = outDir.canonicalFile
            var count = 0
            var bytes = 0L
            val bounded = RandomAccessSliceInputStream(source, offset)
            ZipInputStream(bounded.buffered(CHUNK)).use { zis ->
                while (true) {
                    checkCancelled(cancelled)
                    val e = zis.nextEntry ?: break
                    if (e.isDirectory) continue
                    if (++count > MAX_EMBEDDED_ZIP_ENTRIES) error("embedded ZIP có quá nhiều entry")
                    val target = File(outDir, safeZipPath(e.name)).canonicalFile
                    if (!target.path.startsWith(root.path + File.separator)) error("ZIP path traversal")
                    target.parentFile?.mkdirs()
                    FileOutputStream(target).use { fos ->
                        val buf = ByteArray(CHUNK)
                        while (true) {
                            checkCancelled(cancelled)
                            val n = zis.read(buf)
                            if (n <= 0) break
                            bytes += n
                            if (bytes > MAX_EMBEDDED_ZIP_BYTES) error("embedded ZIP vượt ${human(MAX_EMBEDDED_ZIP_BYTES)}")
                            fos.write(buf, 0, n)
                        }
                    }
                    extracted += target
                }
            }
            extracted
        }.onFailure { warnings += "Không bung được ZIP nhúng ${source.name}@0x${offset.toString(16)}: ${it.message}" }
            .getOrDefault(emptyList())
    }

    private fun safeZipPath(path: String): String = path.replace('\\', '/').split('/')
        .filter { it.isNotBlank() && it != "." && it != ".." }
        .joinToString("/") { it.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(160).ifBlank { "x" } }

    private fun safeId(file: File): String = (file.absolutePath.hashCode().toLong() and 0xffffffffL).toString(16)

    private fun human(n: Long): String = when {
        n >= 1024L * 1024 * 1024 -> "%.2f GiB".format(Locale.US, n / (1024.0 * 1024 * 1024))
        n >= 1024L * 1024 -> "%.1f MiB".format(Locale.US, n / (1024.0 * 1024))
        n >= 1024 -> "%.1f KiB".format(Locale.US, n / 1024.0)
        else -> "$n B"
    }

    private fun indexOf(haystack: ByteArray, needle: ByteArray, from: Int): Int {
        if (needle.isEmpty()) return from.coerceAtMost(haystack.size)
        var i = from
        val last = haystack.size - needle.size
        while (i <= last) {
            var j = 0
            while (j < needle.size && haystack[i + j] == needle[j]) j++
            if (j == needle.size) return i
            i++
        }
        return -1
    }

    private fun checkCancelled(cancelled: () -> Boolean) {
        if (cancelled()) throw CancellationException("Đã hủy")
    }

    private class ByteArrayOutputCollector(val capacity: Int) {
        private val data = ByteArray(capacity)
        var size: Int = 0
            private set
        fun append(src: ByteArray, off: Int, len: Int) {
            val n = minOf(len, capacity - size)
            if (n > 0) {
                System.arraycopy(src, off, data, size, n)
                size += n
            }
        }
        fun bytes(): ByteArray = data.copyOf(size)
    }

    private class RandomAccessSliceInputStream(file: File, offset: Long) : java.io.InputStream() {
        private val raf = RandomAccessFile(file, "r")
        init { raf.seek(offset) }
        override fun read(): Int = raf.read()
        override fun read(b: ByteArray, off: Int, len: Int): Int = raf.read(b, off, len)
        override fun close() = raf.close()
    }
}
