package com.tranloc.apkrigtracer

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CancellationException
import java.util.Locale
import java.util.zip.ZipInputStream

class InputMaterializer(private val context: Context, private val cancelled: () -> Boolean = { false }) {
    data class Result(val root: File, val warnings: List<String>)

    private val maxExpandedBytes = 6L * 1024 * 1024 * 1024
    private val maxEntries = 50_000

    fun fromUri(uri: Uri): Result {
        val workspace = freshWorkspace()
        val warnings = mutableListOf<String>()
        val name = DocumentFile.fromSingleUri(context, uri)?.name ?: "input.bin"
        val original = File(workspace, safeName(name))
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Không mở được file đã chọn" }
            FileOutputStream(original).use { output -> copyChecked(input, output) }
        }
        if (isZipContainer(original)) {
            val unpacked = File(workspace, "unpacked").apply { mkdirs() }
            runCatching { extractInteresting(original, unpacked, warnings) }.onFailure { warnings += "Container không giải nén được như ZIP: ${it.message}" }
        }
        return Result(workspace, warnings)
    }

    fun fromTree(uri: Uri): Result {
        val workspace = freshWorkspace()
        val warnings = mutableListOf<String>()
        val root = DocumentFile.fromTreeUri(context, uri) ?: error("Không đọc được thư mục")
        var bytes = 0L
        var count = 0
        fun walk(node: DocumentFile, outDir: File) {
            if (cancelled()) throw CancellationException("Đã hủy")
            if (++count > maxEntries) error("Thư mục có quá nhiều mục (> $maxEntries)")
            if (node.isDirectory) {
                val dir = File(outDir, safeName(node.name ?: "dir")).apply { mkdirs() }
                node.listFiles().forEach { walk(it, dir) }
            } else if (node.isFile) {
                val len = node.length().coerceAtLeast(0L)
                bytes += len
                if (bytes > maxExpandedBytes) error("Dữ liệu vượt giới hạn 6 GiB của phiên quét")
                val target = File(outDir, safeName(node.name ?: "asset.bin"))
                context.contentResolver.openInputStream(node.uri).use { input ->
                    if (input != null) FileOutputStream(target).use { copyChecked(input, it) }
                }
            }
        }
        root.listFiles().forEach { walk(it, workspace) }
        return Result(workspace, warnings)
    }

    private fun freshWorkspace(): File {
        val base = File(context.cacheDir, "rigtrace")
        base.deleteRecursively(); base.mkdirs()
        return base
    }

    private fun copyChecked(input: java.io.InputStream, output: java.io.OutputStream) {
        val buf = ByteArray(1024 * 1024)
        while (true) {
            if (cancelled()) throw CancellationException("Đã hủy")
            val n = input.read(buf)
            if (n <= 0) break
            output.write(buf, 0, n)
        }
    }

    private fun isZipContainer(file: File): Boolean {
        val n = file.name.lowercase(Locale.ROOT)
        return n.endsWith(".apk") || n.endsWith(".xapk") || n.endsWith(".apks") ||
            n.endsWith(".obb") || n.endsWith(".zip")
    }

    private fun extractInteresting(zip: File, outDir: File, warnings: MutableList<String>) {
        var expanded = 0L
        var entries = 0
        val canonicalRoot = outDir.canonicalFile
        ZipInputStream(zip.inputStream().buffered(1024 * 1024)).use { zis ->
            while (true) {
                if (cancelled()) throw CancellationException("Đã hủy")
                val e = zis.nextEntry ?: break
                if (++entries > maxEntries) error("Container có quá nhiều entry (> $maxEntries)")
                if (e.isDirectory) continue
                if (!interestingEntry(e.name)) continue
                val target = File(outDir, safeZipPath(e.name)).canonicalFile
                if (!target.path.startsWith(canonicalRoot.path + File.separator)) {
                    error("Phát hiện ZIP path traversal: ${e.name}")
                }
                target.parentFile?.mkdirs()
                FileOutputStream(target).use { fos ->
                    val buf = ByteArray(1024 * 1024)
                    while (true) {
                        if (cancelled()) throw CancellationException("Đã hủy")
                        val n = zis.read(buf)
                        if (n <= 0) break
                        expanded += n
                        if (expanded > maxExpandedBytes) error("Dữ liệu giải nén vượt 6 GiB. Có thể là ZIP bomb hoặc game quá lớn.")
                        fos.write(buf, 0, n)
                    }
                }
                if (target.extension.lowercase(Locale.ROOT) in setOf("apk", "zip", "obb")) {
                    val nested = File(target.parentFile, target.nameWithoutExtension + "_unpacked").apply { mkdirs() }
                    runCatching { extractInteresting(target, nested, warnings) }
                        .onFailure { warnings += "Không mở container lồng ${target.name}: ${it.message}" }
                }
            }
        }
        if (expanded == 0L) warnings += "Không thấy asset quen thuộc trong container; tài nguyên có thể tải sau hoặc dùng định dạng riêng."
    }

    private fun interestingEntry(path: String): Boolean {
        val p = path.lowercase(Locale.ROOT)
        val name = p.substringAfterLast('/')
        return p.startsWith("assets/") || p.contains("/assets/") || p.contains("assetbundle") ||
            p.contains("streamingassets") || p.contains("bin/data") ||
            name.endsWith(".assets") || name.endsWith(".ress") || name.endsWith(".resource") ||
            name.endsWith(".bundle") || name.endsWith(".unity3d") || name.endsWith(".ab") ||
            name.endsWith(".aab") || name.endsWith(".pak") || name.endsWith(".ucas") || name.endsWith(".utoc") ||
            name.endsWith(".pck") || name.endsWith(".apk") || name.endsWith(".obb") || name.endsWith(".zip") ||
            name == "globalgamemanagers" || name == "globalgamemanagers.assets" || name == "resources.assets" ||
            name == "sharedassets0.assets" || name == "data.unity3d"
    }

    private fun safeZipPath(path: String): String = path.replace('\\', '/').split('/')
        .filter { it.isNotBlank() && it != "." && it != ".." }.joinToString("/") { safeName(it) }

    private fun safeName(name: String): String = name.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(160)
}
