package com.tranloc.apkrigtracer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tranloc.apkrigtracer.databinding.ActivityMainBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val allModels = mutableListOf<RigSnapshot>()
    private val shown = mutableListOf<RigSnapshot>()
    private var selected = -1
    private var pendingExport: ByteArray? = null
    private var scanJob: Job? = null
    private var lastSummary: ScanSummary? = null

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scanFile(uri)
    }
    private val pickFolder = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) scanFolder(uri)
    }
    private val createGlb = registerForActivityResult(ActivityResultContracts.CreateDocument("model/gltf-binary")) { uri ->
        val data = pendingExport
        pendingExport = null
        if (uri != null && data != null) lifecycleScope.launch(Dispatchers.IO) {
            runCatching { contentResolver.openOutputStream(uri, "w")!!.use { it.write(data) } }
                .onSuccess { withContext(Dispatchers.Main) { toast("Đã lưu GLB") } }
                .onFailure { withContext(Dispatchers.Main) { toast("Lưu thất bại: ${it.message}") } }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.pickFile.setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        b.pickFolder.setOnClickListener { pickFolder.launch(null) }
        b.riggedOnly.setOnCheckedChangeListener { _, _ -> refreshList() }
        b.modelList.setOnItemClickListener { _, _, pos, _ ->
            selected = pos
            val model = shown[pos]
            b.status.text = "${model.status}: ${model.name}"
        }
        b.trace.setOnClickListener { selectedModel()?.let { showTrace(it) } ?: toast("Chọn model trước") }
        b.preview.setOnClickListener {
            selectedModel()?.let {
                SessionStore.selectedRig = it
                startActivity(Intent(this, PreviewActivity::class.java))
            } ?: toast("Chọn model trước")
        }
        b.export.setOnClickListener { selectedModel()?.let { exportModel(it) } ?: toast("Chọn model trước") }
        b.report.setOnClickListener { showReport() }
        b.cancel.setOnClickListener {
            scanJob?.cancel()
            b.status.text = "Đã yêu cầu hủy…"
        }
    }

    private fun scanFile(uri: Uri) = runScan("Đang materialize file…") {
        InputMaterializer(this@MainActivity) { scanJob?.isActive == false }.fromUri(uri)
    }

    private fun scanFolder(uri: Uri) = runScan("Đang materialize thư mục…") {
        InputMaterializer(this@MainActivity) { scanJob?.isActive == false }.fromTree(uri)
    }

    private fun runScan(initial: String, materialize: suspend () -> InputMaterializer.Result) {
        b.status.text = initial
        setBusy(true)
        selected = -1
        lastSummary = null
        allModels.clear()
        refreshList()

        scanJob = lifecycleScope.launch {
            try {
                val result = withContext(Dispatchers.IO) {
                    val m = materialize()
                    val cancelled = { scanJob?.isActive == false }
                    val discovery = UniversalScanner.scan(m.root, cancelled)
                    val warnings = mutableListOf<String>()
                    warnings += m.warnings
                    warnings += discovery.warnings

                    var unityInventory: Map<String, Int> = emptyMap()
                    val models = if (discovery.unityCandidates.isNotEmpty()) {
                        val trace = UnityRigTracer.trace(m.root, discovery.unityCandidates, cancelled)
                        warnings += trace.warnings
                        unityInventory = trace.inventory
                        trace.models
                    } else emptyList()

                    ScanSummary(
                        engine = discovery.primaryEngine,
                        filesScanned = discovery.filesScanned,
                        bytesScanned = discovery.bytesScanned,
                        unityCandidates = discovery.unityCandidates.size,
                        findings = discovery.findings,
                        engineScores = discovery.engineScores,
                        highEntropyFiles = discovery.highEntropyFiles,
                        embeddedContainers = discovery.embeddedContainers,
                        unityInventory = unityInventory,
                        warnings = warnings.distinct(),
                        rigs = models
                    )
                }

                lastSummary = result
                allModels += result.rigs
                refreshList()
                val msg = buildString {
                    append("Engine≈${result.engine}")
                    append(" | Files ${result.filesScanned}")
                    append(" | ${human(result.bytesScanned)}")
                    append(" | Findings ${result.findings.size}")
                    append(" | Models ${result.rigs.size}")
                    append(" | Rigged ${result.rigs.count { it.isRigged }}")
                }
                b.status.text = msg
                showReport()
            } catch (_: CancellationException) {
                b.status.text = "Đã hủy quét"
            } catch (t: Throwable) {
                b.status.text = "Quét thất bại"
                toast("Lỗi: ${t.message ?: t.javaClass.simpleName}")
            } finally {
                setBusy(false)
                scanJob = null
            }
        }
    }

    private fun refreshList() {
        shown.clear()
        shown += if (b.riggedOnly.isChecked) allModels.filter { it.isRigged } else allModels
        val labels = shown.map {
            "${it.status} • ${it.name} • ${it.boneCount} bones • ${it.vertexCount} vtx"
        }
        b.modelList.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, labels)
        selected = -1
    }

    private fun selectedModel(): RigSnapshot? = shown.getOrNull(selected)

    private fun showTrace(r: RigSnapshot) {
        val roots = r.bones.withIndex().filter { it.value.parentIndex < 0 }.joinToString { it.value.name }.ifBlank { "không có" }
        val bones = if (r.bones.isEmpty()) "Không resolve được skeleton." else r.bones.take(120).mapIndexed { i, x ->
            "${i.toString().padStart(3)}  ${"  ".repeat(depthOf(r, i).coerceAtMost(8))}${x.name}"
        }.joinToString("\n")
        val more = if (r.bones.size > 120) "\n… +${r.bones.size - 120} bones" else ""
        val warn = if (r.warnings.isEmpty()) "Không" else r.warnings.joinToString("; ")
        AlertDialog.Builder(this)
            .setTitle("Truy vết: ${r.name}")
            .setMessage(
                "Status: ${r.status}\nType: ${r.kind}\nSource: ${r.source}\n" +
                    "Mesh vertices: ${r.vertexCount}\nTriangles: ${r.indices.size / 3}\n" +
                    "Skeleton: ${r.boneCount} bones\nRoot(s): $roots\n" +
                    "Avatar: ${r.avatarName ?: "không thấy"}\nAnimation trực tiếp: ${r.animationCount}\n" +
                    "Cảnh báo: $warn\n\nBONE TREE\n$bones$more"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun showReport() {
        val s = lastSummary ?: run {
            toast("Chưa có kết quả quét")
            return
        }
        val typeCounts = s.findings.groupingBy { it.type }.eachCount().entries
            .sortedByDescending { it.value }
            .take(28)
            .joinToString("\n") { "${it.key}: ${it.value}" }
            .ifBlank { "Không có signature đã biết" }
        val inventory = s.unityInventory.entries
            .filter { it.value > 0 }
            .sortedByDescending { it.value }
            .take(28)
            .joinToString("\n") { "${it.key}: ${it.value}" }
            .ifBlank { "Unity deep inventory: chưa có" }
        val notable = s.findings
            .filter { it.type !in setOf("PNG", "JPEG", "OGG") }
            .take(35)
            .joinToString("\n") {
                val name = java.io.File(it.filePath).name
                "$name @0x${it.offset.toString(16)} → ${it.type} (${it.confidence}%)${if (it.detail.isNotBlank()) " • ${it.detail}" else ""}"
            }
            .ifBlank { "Không có finding nổi bật." }
        val warnings = s.warnings.take(20).joinToString("\n• ", prefix = if (s.warnings.isEmpty()) "Không" else "• ")

        AlertDialog.Builder(this)
            .setTitle("Universal Scan Report")
            .setMessage(
                "Primary engine signal: ${s.engine}\n" +
                    "Engine scores: ${s.engineScores}\n" +
                    "Files scanned: ${s.filesScanned}\nBytes scanned: ${human(s.bytesScanned)}\n" +
                    "Embedded containers: ${s.embeddedContainers}\nHigh-entropy files: ${s.highEntropyFiles}\n" +
                    "Unity deep candidates: ${s.unityCandidates}\nModels: ${s.rigs.size}\n" +
                    "Rigged: ${s.rigs.count { it.isRigged }}\nUnrigged: ${s.rigs.count { !it.isRigged }}\n\n" +
                    "SIGNATURE INVENTORY\n$typeCounts\n\n" +
                    "UNITY OBJECT INVENTORY\n$inventory\n\n" +
                    "NOTABLE FINDINGS\n$notable\n\n" +
                    "WARNINGS\n$warnings"
            )
            .setPositiveButton("OK", null)
            .show()
    }

    private fun depthOf(r: RigSnapshot, i: Int): Int {
        var d = 0
        var p = r.bones[i].parentIndex
        val seen = HashSet<Int>()
        while (p in r.bones.indices && seen.add(p) && d < 32) {
            d++
            p = r.bones[p].parentIndex
        }
        return d
    }

    private fun exportModel(r: RigSnapshot) {
        if (r.vertexCount > 1_500_000) {
            toast("Model quá lớn (>1.5M vertex) cho export trực tiếp trên điện thoại")
            return
        }
        setBusy(true)
        b.status.text = "Đang đóng gói GLB…"
        lifecycleScope.launch {
            val res = withContext(Dispatchers.Default) { runCatching { GlbWriter.write(r) } }
            setBusy(false)
            res.onSuccess {
                pendingExport = it
                createGlb.launch(safeFileName(r.name) + ".glb")
            }.onFailure {
                b.status.text = "Export lỗi"
                toast("Export lỗi: ${it.message}")
            }
        }
    }

    private fun safeFileName(s: String) = s.replace(Regex("[^A-Za-z0-9._ -]"), "_").take(80).ifBlank { "model" }

    private fun setBusy(v: Boolean) {
        b.pickFile.isEnabled = !v
        b.pickFolder.isEnabled = !v
        b.trace.isEnabled = !v
        b.preview.isEnabled = !v
        b.export.isEnabled = !v
        b.report.isEnabled = !v
        b.cancel.isEnabled = v
    }

    private fun human(n: Long): String = when {
        n >= 1024L * 1024 * 1024 -> "%.2f GiB".format(Locale.US, n / (1024.0 * 1024 * 1024))
        n >= 1024L * 1024 -> "%.1f MiB".format(Locale.US, n / (1024.0 * 1024))
        n >= 1024 -> "%.1f KiB".format(Locale.US, n / 1024.0)
        else -> "$n B"
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
