# Third-party notices

## UnityKt
APK Rig Tracer V1 uses UnityKt by Deficuet for read-only Unity asset parsing.
Repository: https://github.com/Deficuet/UnityKt
License: GPL-3.0.
Pinned commit: e032b918729d89e02ed333c0baaac9aa25b2cb76

The V1 intentionally does not use UnityKt's Windows-only native texture decoder path.
