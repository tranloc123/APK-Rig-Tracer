# Build status

- [x] Android project structure created
- [x] SAF file/folder import
- [x] ZIP safety limits and path traversal protection
- [x] APK/XAPK/APKS/OBB nested scanning
- [x] Unity/Unreal/Godot detection
- [x] Unity SkinnedMeshRenderer -> Mesh -> bones -> Animator/Avatar tracing
- [x] CPU skinning + test poses
- [x] OpenGL ES 3 preview
- [x] GLB mesh+skin+skeleton exporter
- [x] Android Save As / download button
- [x] GitHub Actions APK workflow
- [x] Pure Kotlin core (Model + Math3D) compile check
- [ ] Full Android Gradle compile in this runtime (Android SDK is not installed here)
- [ ] APK runtime validation on a physical Android device
