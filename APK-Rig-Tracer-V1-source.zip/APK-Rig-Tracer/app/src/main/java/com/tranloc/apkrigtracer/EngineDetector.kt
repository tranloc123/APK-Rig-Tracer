package com.tranloc.apkrigtracer

import java.io.File
import java.util.Locale

object EngineDetector {
    data class Detection(val engine: String, val unityFiles: List<File>, val warnings: List<String>, val filesScanned: Int)

    fun detect(root: File): Detection {
        val all = root.walkTopDown().filter { it.isFile }.take(60_000).toList()
        var unity = 0; var unreal = 0; var godot = 0
        val unityFiles = mutableListOf<File>()
        for (f in all) {
            val n = f.name.lowercase(Locale.ROOT)
            val p = f.path.lowercase(Locale.ROOT)
            val magic = readMagic(f)
            val isUnity = magic.startsWith("UnityFS") || magic.startsWith("UnityWeb") || magic.startsWith("UnityRaw") ||
                n.endsWith(".assets") || n == "globalgamemanagers" || n == "resources.assets" ||
                n.endsWith(".bundle") || n.endsWith(".unity3d") || p.contains("/bin/data/") || p.contains("streamingassets")
            if (isUnity) { unity++; unityFiles += f }
            if (n.endsWith(".pak") || n.endsWith(".ucas") || n.endsWith(".utoc") || p.contains("unrealengine")) unreal++
            if (n.endsWith(".pck") || p.contains("godot")) godot++
        }
        val engine = when {
            unity > 0 && unity >= unreal && unity >= godot -> "Unity"
            unreal > 0 && unreal >= godot -> "Unreal"
            godot > 0 -> "Godot"
            else -> "Unknown"
        }
        val warnings = mutableListOf<String>()
        if (engine == "Unknown") warnings += "Không nhận diện được engine từ dữ liệu hiện có."
        if (engine != "Unity" && engine != "Unknown") warnings += "V1 mới truy vết rig sâu cho Unity; engine $engine hiện chỉ được nhận diện."
        return Detection(engine, unityFiles.distinctBy { it.absolutePath }, warnings, all.size)
    }

    private fun readMagic(f: File): String = runCatching {
        f.inputStream().use { input ->
            val b = ByteArray(16); val n = input.read(b); if (n <= 0) "" else String(b, 0, n, Charsets.ISO_8859_1)
        }
    }.getOrDefault("")
}
