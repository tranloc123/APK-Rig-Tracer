package com.tranloc.apkrigtracer

import io.github.deficuet.unitykt.UnityAssetManager
import io.github.deficuet.unitykt.classes.*
import io.github.deficuet.unitykt.pptr.safeGetObj
import java.io.File
import java.util.concurrent.CancellationException
import java.util.zip.CRC32

object UnityRigTracer {
    data class TraceResult(
        val models: List<RigSnapshot>,
        val warnings: List<String>,
        val inventory: Map<String, Int>
    )

    fun trace(
        root: File,
        candidates: List<File>,
        cancelled: () -> Boolean = { false }
    ): TraceResult {
        val warnings = mutableListOf<String>()
        val models = mutableListOf<RigSnapshot>()
        var inventory: Map<String, Int> = emptyMap()

        UnityAssetManager.new(root, debugOutput = { msg ->
            if (msg.contains("error", true) || msg.contains("fail", true)) warnings += msg.take(400)
        }).use { manager ->
            var loaded = 0
            for (f in candidates.distinctBy { it.absolutePath }) {
                if (cancelled()) throw CancellationException("Đã hủy")
                runCatching { manager.loadFile(f) }
                    .onSuccess { loaded++ }
                    .onFailure { warnings += "Unity deep parse bỏ qua ${f.name}: ${it.message ?: it.javaClass.simpleName}" }
            }
            warnings += "Unity deep parser nạp được $loaded/${candidates.distinctBy { it.absolutePath }.size} candidate."

            val objects = manager.objectList
            inventory = objects.groupingBy { it.javaClass.simpleName }.eachCount().toSortedMap()
            val transforms = objects.filterIsInstance<Transform>()
            val hashMap = buildTransformHashMap(transforms)
            val renderers = objects.filterIsInstance<SkinnedMeshRenderer>()
            val usedMeshes = HashSet<Long>()

            for (smr in renderers) {
                if (cancelled()) throw CancellationException("Đã hủy")
                runCatching { buildSnapshot(smr, hashMap) }
                    .onSuccess { snap ->
                        if (snap != null) {
                            models += snap
                            val mesh = smr.mMesh.safeGetObj()
                            if (mesh != null) usedMeshes += mesh.mPathID
                        }
                    }
                    .onFailure { warnings += "SkinnedMeshRenderer parse lỗi: ${it.message}" }
            }

            // V1 silently hid meshes without a resolvable rig. V2 always exposes them.
            for (mesh in objects.filterIsInstance<Mesh>()) {
                if (cancelled()) throw CancellationException("Đã hủy")
                if (mesh.mPathID in usedMeshes) continue
                runCatching { buildStaticSnapshot(mesh, listOf("Mesh chưa liên kết với SkinnedMeshRenderer/rig đã resolve.")) }
                    .onSuccess { if (it != null) models += it }
                    .onFailure { warnings += "Mesh parse lỗi ${mesh.mName}: ${it.message}" }
            }
        }

        if (models.isEmpty()) {
            warnings += "Unity objects đã được kiểm kê nhưng chưa dựng được Mesh nào. Xem Báo cáo để phân biệt parser fail, asset ngoài APK hoặc dữ liệu nén/mã hóa."
        }
        return TraceResult(
            models = models.distinctBy { it.source + "#" + it.name + "#" + it.vertexCount },
            warnings = warnings.distinct().take(80),
            inventory = inventory
        )
    }

    private fun buildSnapshot(smr: SkinnedMeshRenderer, hashMap: Map<Long, Transform>): RigSnapshot? {
        val mesh = smr.mMesh.safeGetObj() ?: return null
        val go = smr.mGameObject.safeGetObj()
        val name = go?.mName?.takeIf { it.isNotBlank() } ?: mesh.mName.ifBlank { "Mesh_${mesh.mPathID}" }

        var transforms = smr.mBones.mapNotNull { it.safeGetObj() }
        val warnings = mutableListOf<String>()
        if (transforms.isEmpty()) {
            val hashes = readBoneHashes(mesh)
            if (hashes.isNotEmpty()) {
                val reconstructed = hashes.mapNotNull { hashMap[it] }
                if (reconstructed.size == hashes.size) {
                    transforms = reconstructed
                    warnings += "Bones được khôi phục từ m_BoneNameHashes/path CRC32."
                } else {
                    warnings += "m_Bones rỗng; hash fallback khớp ${reconstructed.size}/${hashes.size} bones."
                }
            }
        }

        if (transforms.isEmpty()) {
            return buildStaticSnapshot(mesh, warnings + "SkinnedMeshRenderer tồn tại nhưng không resolve được bone references.")
                ?.copy(name = name, avatarName = go?.mAnimator?.mAvatar?.safeGetObj()?.mName)
        }

        val indexById = transforms.mapIndexed { i, t -> t.mPathID to i }.toMap()
        val bind = mesh.mBindPose
        val bones = transforms.mapIndexed { i, t ->
            val bgo = t.mGameObject.safeGetObj()
            val parentId = t.mFather.mPathID
            val inv = if (i < bind.size) FloatArray(16) { k ->
                val col = k / 4
                val row = k % 4
                bind[i][row, col]
            } else identity16()
            BoneSnapshot(
                name = bgo?.mName?.ifBlank { "Bone_$i" } ?: "Bone_$i",
                pathId = t.mPathID,
                parentIndex = indexById[parentId] ?: -1,
                tx = t.mLocalPosition.x, ty = t.mLocalPosition.y, tz = t.mLocalPosition.z,
                qx = t.mLocalRotation.a, qy = t.mLocalRotation.b, qz = t.mLocalRotation.c, qw = t.mLocalRotation.d,
                sx = t.mLocalScale.x, sy = t.mLocalScale.y, sz = t.mLocalScale.z,
                inverseBind = inv
            )
        }

        val v = mesh.mVertices
        val skin = mesh.mSkin
        val vertexCount = mesh.mVertexCount.coerceAtMost(v.size / 3)
        if (vertexCount <= 0) return null
        val jointIdx = IntArray(vertexCount * 4)
        val weights = FloatArray(vertexCount * 4)
        for (i in 0 until minOf(vertexCount, skin.size)) {
            val s = skin[i]
            for (j in 0 until 4) {
                jointIdx[i * 4 + j] = s.boneIndex.getOrElse(j) { 0 }.coerceIn(0, maxOf(0, bones.lastIndex))
                weights[i * 4 + j] = s.weight.getOrElse(j) { 0f }
            }
            val sum = (0..3).sumOf { weights[i * 4 + it].toDouble() }.toFloat()
            if (sum > 0f && kotlin.math.abs(sum - 1f) > 0.001f) {
                for (j in 0..3) weights[i * 4 + j] /= sum
            }
        }
        val idx = mesh.mIndices.map { it.toLong().toInt() }.toIntArray()
        val avatar = go?.mAnimator?.mAvatar?.safeGetObj()?.mName
        val animCount = go?.mAnimation?.mAnimations?.count { it.safeGetObj() != null } ?: 0
        if (bind.size != bones.size) warnings += "Bind pose ${bind.size} != bones ${bones.size}"
        if (skin.size < vertexCount) warnings += "Skin weights thiếu: ${skin.size}/$vertexCount vertex"

        return RigSnapshot(
            name = name,
            source = sourceOf(mesh),
            vertices = v.copyOf(vertexCount * 3),
            normals = mesh.mNormals,
            indices = idx,
            boneIndices = jointIdx,
            boneWeights = weights,
            bones = bones,
            avatarName = avatar,
            animationCount = animCount,
            warnings = warnings,
            kind = "UNITY_SKINNED_MESH"
        )
    }

    private fun buildStaticSnapshot(mesh: Mesh, warnings: List<String>): RigSnapshot? {
        val v = mesh.mVertices
        val vertexCount = mesh.mVertexCount.coerceAtMost(v.size / 3)
        if (vertexCount <= 0) return null
        val idx = mesh.mIndices.map { it.toLong().toInt() }.toIntArray()
        return RigSnapshot(
            name = mesh.mName.ifBlank { "Mesh_${mesh.mPathID}" },
            source = sourceOf(mesh),
            vertices = v.copyOf(vertexCount * 3),
            normals = mesh.mNormals,
            indices = idx,
            boneIndices = IntArray(0),
            boneWeights = FloatArray(0),
            bones = emptyList(),
            avatarName = null,
            animationCount = 0,
            warnings = warnings,
            kind = "UNITY_MESH"
        )
    }

    private fun sourceOf(mesh: Mesh): String = runCatching {
        File(mesh.context.parent, mesh.context.name).path
    }.getOrElse { mesh.context.name }

    /**
     * Unity commonly hashes transform paths for bone references. We register full paths
     * and every suffix path so a mesh whose root is below the scene root still has a chance
     * to resolve.
     */
    private fun buildTransformHashMap(transforms: List<Transform>): Map<Long, Transform> {
        val byId = transforms.associateBy { it.mPathID }
        val pathCache = HashMap<Long, String>()
        fun pathOf(t: Transform, depth: Int = 0): String {
            pathCache[t.mPathID]?.let { return it }
            val name = t.mGameObject.safeGetObj()?.mName?.ifBlank { "Bone_${t.mPathID}" } ?: "Bone_${t.mPathID}"
            if (depth > 128) return name
            val parent = byId[t.mFather.mPathID]
            val p = if (parent == null) name else pathOf(parent, depth + 1) + "/" + name
            pathCache[t.mPathID] = p
            return p
        }

        val out = LinkedHashMap<Long, Transform>()
        for (t in transforms) {
            val parts = pathOf(t).split('/')
            for (start in parts.indices) {
                val suffix = parts.subList(start, parts.size).joinToString("/")
                out.putIfAbsent(crc32(suffix), t)
            }
        }
        return out
    }

    private fun readBoneHashes(mesh: Mesh): List<Long> =
        mesh.mBoneNameHashes.map { it.toLong() and 0xffffffffL }

    private fun crc32(s: String): Long = CRC32().run {
        update(s.toByteArray(Charsets.UTF_8))
        value and 0xffffffffL
    }

    private fun identity16() = FloatArray(16) { if (it % 5 == 0) 1f else 0f }
}
