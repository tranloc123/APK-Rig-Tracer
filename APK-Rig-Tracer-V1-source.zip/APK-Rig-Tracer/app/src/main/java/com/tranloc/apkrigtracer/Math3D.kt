package com.tranloc.apkrigtracer

import kotlin.math.*

data class Quat(val x:Float,val y:Float,val z:Float,val w:Float){
    operator fun times(o:Quat)=Quat(
        w*o.x+x*o.w+y*o.z-z*o.y,
        w*o.y-x*o.z+y*o.w+z*o.x,
        w*o.z+x*o.y-y*o.x+z*o.w,
        w*o.w-x*o.x-y*o.y-z*o.z
    ).normalized()
    fun normalized():Quat{val l=sqrt(x*x+y*y+z*z+w*w).coerceAtLeast(1e-8f);return Quat(x/l,y/l,z/l,w/l)}
    companion object{
        fun euler(xDeg:Float,yDeg:Float,zDeg:Float):Quat{
            val x=xDeg*PI.toFloat()/180/2; val y=yDeg*PI.toFloat()/180/2; val z=zDeg*PI.toFloat()/180/2
            val sx=sin(x);val cx=cos(x);val sy=sin(y);val cy=cos(y);val sz=sin(z);val cz=cos(z)
            return Quat(sx*cy*cz-cx*sy*sz,cx*sy*cz+sx*cy*sz,cx*cy*sz-sx*sy*cz,cx*cy*cz+sx*sy*sz)
        }
    }
}

object Mat4 {
    fun identity()=FloatArray(16){if(it%5==0)1f else 0f}
    fun mul(a:FloatArray,b:FloatArray):FloatArray{val o=FloatArray(16);for(c in 0..3)for(r in 0..3)o[c*4+r]=(0..3).sumOf{k->(a[k*4+r]*b[c*4+k]).toDouble()}.toFloat();return o}
    fun trs(tx:Float,ty:Float,tz:Float,q:Quat,sx:Float,sy:Float,sz:Float):FloatArray{
        val x=q.x;val y=q.y;val z=q.z;val w=q.w
        val m=identity()
        m[0]=(1-2*y*y-2*z*z)*sx;m[1]=(2*x*y+2*w*z)*sx;m[2]=(2*x*z-2*w*y)*sx
        m[4]=(2*x*y-2*w*z)*sy;m[5]=(1-2*x*x-2*z*z)*sy;m[6]=(2*y*z+2*w*x)*sy
        m[8]=(2*x*z+2*w*y)*sz;m[9]=(2*y*z-2*w*x)*sz;m[10]=(1-2*x*x-2*y*y)*sz
        m[12]=tx;m[13]=ty;m[14]=tz;return m
    }
    fun transform(m:FloatArray,x:Float,y:Float,z:Float):FloatArray=floatArrayOf(
        m[0]*x+m[4]*y+m[8]*z+m[12],m[1]*x+m[5]*y+m[9]*z+m[13],m[2]*x+m[6]*y+m[10]*z+m[14])
    fun perspective(fov:Float,aspect:Float,near:Float,far:Float):FloatArray{val f=1f/tan(fov*PI.toFloat()/360f);return floatArrayOf(f/aspect,0f,0f,0f,0f,f,0f,0f,0f,0f,(far+near)/(near-far),-1f,0f,0f,2f*far*near/(near-far),0f)}
    fun translate(x:Float,y:Float,z:Float)=identity().also{it[12]=x;it[13]=y;it[14]=z}
    fun rotateY(deg:Float):FloatArray{val a=deg*PI.toFloat()/180;val c=cos(a);val s=sin(a);return floatArrayOf(c,0f,-s,0f,0f,1f,0f,0f,s,0f,c,0f,0f,0f,0f,1f)}
}

enum class TestPose { BIND, T_POSE, WAVE, JUMP, SQUAT, HIPHOP }

object PoseEngine {
    private fun side(name:String,left:Boolean)=if(left) Regex("(^|[_ .-])(l|left)([_ .-]|$)|left",RegexOption.IGNORE_CASE).containsMatchIn(name)
        else Regex("(^|[_ .-])(r|right)([_ .-]|$)|right",RegexOption.IGNORE_CASE).containsMatchIn(name)
    fun delta(name:String,pose:TestPose):Quat{
        val n=name.lowercase()
        val upper=n.contains("upperarm")||n.contains("uparm")||n.contains("shoulder")
        val lower=n.contains("lowerarm")||n.contains("forearm")
        val thigh=n.contains("thigh")||n.contains("upperleg")
        val calf=n.contains("calf")||n.contains("lowerleg")||n.contains("shin")
        val hips=n.contains("hips")||n.contains("pelvis")
        val spine=n.contains("spine")||n.contains("chest")
        return when(pose){
            TestPose.BIND -> Quat(0f,0f,0f,1f)
            TestPose.T_POSE -> when{upper&&side(name,true)->Quat.euler(0f,0f,70f);upper&&side(name,false)->Quat.euler(0f,0f,-70f);else->Quat(0f,0f,0f,1f)}
            TestPose.WAVE -> when{upper&&side(name,true)->Quat.euler(-20f,0f,65f);lower&&side(name,true)->Quat.euler(0f,-15f,70f);else->Quat(0f,0f,0f,1f)}
            TestPose.JUMP -> when{upper->Quat.euler(-35f,0f,if(side(name,true))45f else -45f);thigh->Quat.euler(-15f,0f,0f);else->Quat(0f,0f,0f,1f)}
            TestPose.SQUAT -> when{thigh->Quat.euler(55f,0f,0f);calf->Quat.euler(-90f,0f,0f);spine->Quat.euler(-12f,0f,0f);else->Quat(0f,0f,0f,1f)}
            TestPose.HIPHOP -> when{hips->Quat.euler(0f,18f,8f);spine->Quat.euler(0f,-14f,-8f);upper->Quat.euler(if(side(name,true))-25f else 30f,0f,if(side(name,true))35f else -55f);else->Quat(0f,0f,0f,1f)}
        }
    }

    fun boneWorlds(rig:RigSnapshot,pose:TestPose):Array<FloatArray>{
        val worlds=Array(rig.boneCount){Mat4.identity()};val done=BooleanArray(rig.boneCount)
        fun solve(i:Int):FloatArray{if(done[i])return worlds[i];val b=rig.bones[i];val base=Quat(b.qx,b.qy,b.qz,b.qw);val q=base*delta(b.name,pose);val local=Mat4.trs(b.tx,b.ty,b.tz,q,b.sx,b.sy,b.sz);worlds[i]=if(b.parentIndex in rig.bones.indices)Mat4.mul(solve(b.parentIndex),local)else local;done[i]=true;return worlds[i]}
        rig.bones.indices.forEach{solve(it)};return worlds
    }

    fun skinnedVertices(rig:RigSnapshot,pose:TestPose):FloatArray{
        if(!rig.isRigged)return rig.vertices.copyOf();val worlds=boneWorlds(rig,pose);val skin=Array(rig.boneCount){i->Mat4.mul(worlds[i],rig.bones[i].inverseBind)};val out=FloatArray(rig.vertexCount*3)
        for(i in 0 until rig.vertexCount){val x=rig.vertices[i*3];val y=rig.vertices[i*3+1];val z=rig.vertices[i*3+2];var ox=0f;var oy=0f;var oz=0f;var sum=0f
            for(j in 0..3){val w=rig.boneWeights.getOrElse(i*4+j){0f};if(w<=0f)continue;val bi=rig.boneIndices.getOrElse(i*4+j){0}.coerceIn(0,rig.boneCount-1);val p=Mat4.transform(skin[bi],x,y,z);ox+=p[0]*w;oy+=p[1]*w;oz+=p[2]*w;sum+=w}
            if(sum<=0f){ox=x;oy=y;oz=z};out[i*3]=ox;out[i*3+1]=oy;out[i*3+2]=oz}
        return out
    }
}
