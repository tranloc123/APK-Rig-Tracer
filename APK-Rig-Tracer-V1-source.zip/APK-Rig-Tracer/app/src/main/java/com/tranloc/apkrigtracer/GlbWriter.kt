package com.tranloc.apkrigtracer

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

object GlbWriter {
    private data class Slice(val offset:Int,val length:Int)

    fun write(rig:RigSnapshot):ByteArray {
        require(rig.vertexCount>0){"Model không có vertex"};require(rig.boneCount>0){"Model không có skeleton"}
        val bin=ByteArrayOutputStream()
        fun align4(){while(bin.size()%4!=0)bin.write(0)}
        fun put(bytes:ByteArray):Slice{align4();val o=bin.size();bin.write(bytes);return Slice(o,bytes.size)}

        val pos=FloatArray(rig.vertices.size)
        for(i in 0 until rig.vertexCount){pos[i*3]=-rig.vertices[i*3];pos[i*3+1]=rig.vertices[i*3+1];pos[i*3+2]=rig.vertices[i*3+2]}
        val posS=put(floats(pos))
        val normalsValid=rig.normals.size>=rig.vertexCount*3
        val nrmS=if(normalsValid){val n=FloatArray(rig.vertexCount*3);for(i in 0 until rig.vertexCount){n[i*3]=-rig.normals[i*3];n[i*3+1]=rig.normals[i*3+1];n[i*3+2]=rig.normals[i*3+2]};put(floats(n))}else null
        val joints=ShortArray(rig.vertexCount*4){rig.boneIndices.getOrElse(it){0}.coerceIn(0,65535).toShort()}
        val jntS=put(shorts(joints));val wgtS=put(floats(rig.boneWeights.copyOf(rig.vertexCount*4)))
        val triCount=rig.indices.size/3;val rev=IntArray(triCount*3)
        for(t in 0 until triCount){rev[t*3]=rig.indices[t*3+2];rev[t*3+1]=rig.indices[t*3+1];rev[t*3+2]=rig.indices[t*3]}
        val idxS=put(ints(rev))
        val ibm=FloatArray(rig.boneCount*16);val sign=floatArrayOf(-1f,1f,1f,1f)
        for(b in rig.bones.indices){val src=rig.bones[b].inverseBind;for(c in 0..3)for(r in 0..3){val v=src.getOrElse(c*4+r){if(r==c)1f else 0f};ibm[b*16+c*4+r]=sign[r]*v*sign[c]}}
        val ibmS=put(floats(ibm));align4();val binBytes=bin.toByteArray()

        val views=mutableListOf<Any?>()
        fun view(s:Slice,target:Int?=null):Int{val m=linkedMapOf<String,Any?>("buffer" to 0,"byteOffset" to s.offset,"byteLength" to s.length);if(target!=null)m["target"]=target;views+=m;return views.lastIndex}
        val vPos=view(posS,34962);val vNrm=nrmS?.let{view(it,34962)};val vJnt=view(jntS,34962);val vWgt=view(wgtS,34962);val vIdx=view(idxS,34963);val vIbm=view(ibmS)

        val accessors=mutableListOf<Any?>()
        fun acc(view:Int,comp:Int,count:Int,type:String,min:List<Number>?=null,max:List<Number>?=null):Int{val m=linkedMapOf<String,Any?>("bufferView" to view,"componentType" to comp,"count" to count,"type" to type);if(min!=null)m["min"]=min;if(max!=null)m["max"]=max;accessors+=m;return accessors.lastIndex}
        var minX=Float.POSITIVE_INFINITY;var minY=minX;var minZ=minX;var maxX=Float.NEGATIVE_INFINITY;var maxY=maxX;var maxZ=maxX
        for(i in 0 until rig.vertexCount){val x=pos[i*3];val y=pos[i*3+1];val z=pos[i*3+2];minX=minOf(minX,x);minY=minOf(minY,y);minZ=minOf(minZ,z);maxX=maxOf(maxX,x);maxY=maxOf(maxY,y);maxZ=maxOf(maxZ,z)}
        val aPos=acc(vPos,5126,rig.vertexCount,"VEC3",listOf(minX,minY,minZ),listOf(maxX,maxY,maxZ));val aNrm=vNrm?.let{acc(it,5126,rig.vertexCount,"VEC3")};val aJnt=acc(vJnt,5123,rig.vertexCount,"VEC4");val aWgt=acc(vWgt,5126,rig.vertexCount,"VEC4");val aIdx=acc(vIdx,5125,rev.size,"SCALAR",listOf(0),listOf(rev.maxOrNull()?:0));val aIbm=acc(vIbm,5126,rig.boneCount,"MAT4")

        val attrs=linkedMapOf<String,Any?>("POSITION" to aPos,"JOINTS_0" to aJnt,"WEIGHTS_0" to aWgt);if(aNrm!=null)attrs["NORMAL"]=aNrm
        val mesh=linkedMapOf<String,Any?>("name" to rig.name,"primitives" to listOf(linkedMapOf<String,Any?>("attributes" to attrs,"indices" to aIdx,"mode" to 4)))
        val nodes=mutableListOf<MutableMap<String,Any?>>()
        for(b in rig.bones)nodes+=linkedMapOf("name" to b.name,"translation" to listOf(-b.tx,b.ty,b.tz),"rotation" to listOf(b.qx,-b.qy,-b.qz,b.qw),"scale" to listOf(b.sx,b.sy,b.sz))
        for(i in rig.bones.indices){val ch=rig.bones.indices.filter{rig.bones[it].parentIndex==i};if(ch.isNotEmpty())nodes[i]["children"]=ch}
        val meshNode=nodes.size;nodes+=linkedMapOf("name" to rig.name,"mesh" to 0,"skin" to 0)
        val roots=rig.bones.indices.filter{rig.bones[it].parentIndex !in rig.bones.indices};val sceneNodes=roots+meshNode
        val skin=linkedMapOf<String,Any?>("name" to "${rig.name}_Skin","inverseBindMatrices" to aIbm,"joints" to rig.bones.indices.toList());if(roots.isNotEmpty())skin["skeleton"]=roots.first()
        val root=linkedMapOf<String,Any?>(
            "asset" to linkedMapOf("version" to "2.0","generator" to "APK Rig Tracer V1"),
            "buffers" to listOf(linkedMapOf("byteLength" to binBytes.size)),"bufferViews" to views,"accessors" to accessors,
            "meshes" to listOf(mesh),"nodes" to nodes,"skins" to listOf(skin),"scenes" to listOf(linkedMapOf("nodes" to sceneNodes)),"scene" to 0)
        val jsonBytes=json(root).toByteArray(Charsets.UTF_8);val jp=(4-jsonBytes.size%4)%4;val bp=(4-binBytes.size%4)%4;val total=12+8+jsonBytes.size+jp+8+binBytes.size+bp
        return ByteBuffer.allocate(total).order(ByteOrder.LITTLE_ENDIAN).apply{
            putInt(0x46546C67);putInt(2);putInt(total);putInt(jsonBytes.size+jp);putInt(0x4E4F534A);this.put(jsonBytes);repeat(jp){this.put(0x20)};putInt(binBytes.size+bp);putInt(0x004E4942);this.put(binBytes);repeat(bp){this.put(0)}
        }.array()
    }

    private fun json(v:Any?):String=when(v){
        null->"null";is String->"\""+v.replace("\\","\\\\").replace("\"","\\\"").replace("\n","\\n").replace("\r","\\r").replace("\t","\\t")+"\""
        is Boolean->if(v)"true" else "false";is Number->{val d=v.toDouble();if(d.isFinite())v.toString() else "0"}
        is Map<*,*>->v.entries.joinToString(",","{","}"){json(it.key.toString())+":"+json(it.value)}
        is Iterable<*>->v.joinToString(",","[","]"){json(it)}
        is IntArray->v.joinToString(",","[","]");is FloatArray->v.joinToString(",","[","]"){if(it.isFinite())it.toString() else "0"}
        else->json(v.toString())
    }
    private fun floats(a:FloatArray)=ByteBuffer.allocate(a.size*4).order(ByteOrder.LITTLE_ENDIAN).apply{a.forEach{putFloat(it)}}.array()
    private fun ints(a:IntArray)=ByteBuffer.allocate(a.size*4).order(ByteOrder.LITTLE_ENDIAN).apply{a.forEach{putInt(it)}}.array()
    private fun shorts(a:ShortArray)=ByteBuffer.allocate(a.size*2).order(ByteOrder.LITTLE_ENDIAN).apply{a.forEach{putShort(it)}}.array()
}
