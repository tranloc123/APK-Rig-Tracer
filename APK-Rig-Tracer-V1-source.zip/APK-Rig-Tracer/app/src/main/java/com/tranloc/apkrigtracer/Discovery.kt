package com.tranloc.apkrigtracer

import java.io.File

data class ArtifactFinding(
    val filePath: String,
    val type: String,
    val offset: Long,
    val confidence: Int,
    val detail: String = "",
    val embedded: Boolean = false
)

data class UniversalScanResult(
    val filesScanned: Int,
    val bytesScanned: Long,
    val findings: List<ArtifactFinding>,
    val unityCandidates: List<File>,
    val engineScores: Map<String, Int>,
    val highEntropyFiles: Int,
    val embeddedContainers: Int,
    val warnings: List<String>
) {
    val primaryEngine: String
        get() = engineScores.maxByOrNull { it.value }?.takeIf { it.value > 0 }?.key ?: "Unknown"

    fun typeCounts(): Map<String, Int> = findings.groupingBy { it.type }.eachCount().toSortedMap()
}
