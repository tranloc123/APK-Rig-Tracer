package com.tranloc.apkrigtracer

import android.content.Context
import android.opengl.GLES30
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.IntBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.max
import kotlin.math.sqrt

class RigPreviewView(context: Context, private val rig: RigSnapshot): GLSurfaceView(context) {
    private val rendererImpl = RigRenderer(rig)
    init { setEGLContextClientVersion(3); setRenderer(rendererImpl); renderMode = RENDERMODE_WHEN_DIRTY }
    fun setPose(pose: TestPose) { queueEvent { rendererImpl.setPose(pose) }; requestRender() }
    fun rotateBy(delta: Float) { queueEvent { rendererImpl.rotation += delta }; requestRender() }
}

private class RigRenderer(private val rig: RigSnapshot): GLSurfaceView.Renderer {
    private var program=0
    private var posLoc=0; private var mvpLoc=0; private var colorLoc=0
    private var vertexBuffer: FloatBuffer?=null
    private var indexBuffer: IntBuffer?=null
    private var skeletonBuffer: FloatBuffer?=null
    private var drawIndexCount=0; private var skeletonVertexCount=0
    private var width=1; private var height=1
    var rotation=25f
    private var pose=TestPose.BIND
    private var center=floatArrayOf(0f,0f,0f); private var radius=1f

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        program=createProgram(VS,FS)
        posLoc=GLES30.glGetAttribLocation(program,"aPos")
        mvpLoc=GLES30.glGetUniformLocation(program,"uMvp")
        colorLoc=GLES30.glGetUniformLocation(program,"uColor")
        indexBuffer=directIntBuffer(rig.indices.copyOf((rig.indices.size/3)*3))
        drawIndexCount=indexBuffer?.capacity()?:0
        rebuild()
    }
    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) { width=max(1,w);height=max(1,h);GLES30.glViewport(0,0,width,height) }
    override fun onDrawFrame(gl: GL10?) {
        GLES30.glClearColor(0.055f,0.065f,0.085f,1f)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)
        val projection=FloatArray(16);val view=FloatArray(16);val model=FloatArray(16);val mv=FloatArray(16);val mvp=FloatArray(16)
        Matrix.perspectiveM(projection,0,45f,width.toFloat()/height,0.01f,max(100f,radius*10f))
        Matrix.setLookAtM(view,0,0f,0f,max(2.5f,radius*2.7f),0f,0f,0f,0f,1f,0f)
        Matrix.setIdentityM(model,0);Matrix.rotateM(model,0,rotation,0f,1f,0f);Matrix.translateM(model,0,-center[0],-center[1],-center[2])
        Matrix.multiplyMM(mv,0,view,0,model,0);Matrix.multiplyMM(mvp,0,projection,0,mv,0)
        GLES30.glUseProgram(program);GLES30.glUniformMatrix4fv(mvpLoc,1,false,mvp,0)
        vertexBuffer?.let { vb ->
            vb.position(0);GLES30.glEnableVertexAttribArray(posLoc);GLES30.glVertexAttribPointer(posLoc,3,GLES30.GL_FLOAT,false,12,vb)
            GLES30.glUniform4f(colorLoc,0.72f,0.75f,0.80f,1f)
            indexBuffer?.let { ib -> ib.position(0);GLES30.glDrawElements(GLES30.GL_TRIANGLES,drawIndexCount,GLES30.GL_UNSIGNED_INT,ib) }
        }
        skeletonBuffer?.let { sb ->
            GLES30.glDisable(GLES30.GL_CULL_FACE);GLES30.glLineWidth(4f);sb.position(0);GLES30.glVertexAttribPointer(posLoc,3,GLES30.GL_FLOAT,false,12,sb)
            GLES30.glUniform4f(colorLoc,0.20f,0.90f,0.72f,1f);GLES30.glDrawArrays(GLES30.GL_LINES,0,skeletonVertexCount);GLES30.glEnable(GLES30.GL_CULL_FACE)
        }
        GLES30.glDisableVertexAttribArray(posLoc)
    }

    fun setPose(p:TestPose){pose=p;rebuild()}
    private fun rebuild(){
        val v=PoseEngine.skinnedVertices(rig,pose);vertexBuffer=directFloatBuffer(v);computeBounds(v)
        val worlds=PoseEngine.boneWorlds(rig,pose);val lines=ArrayList<Float>()
        for(i in rig.bones.indices){val pi=rig.bones[i].parentIndex;if(pi !in rig.bones.indices)continue;val a=Mat4.transform(worlds[pi],0f,0f,0f);val b=Mat4.transform(worlds[i],0f,0f,0f);lines.addAll(listOf(a[0],a[1],a[2],b[0],b[1],b[2]))}
        skeletonVertexCount=lines.size/3;skeletonBuffer=directFloatBuffer(lines.toFloatArray())
    }
    private fun computeBounds(v:FloatArray){if(v.size<3){center=floatArrayOf(0f,0f,0f);radius=1f;return};var minX=v[0];var maxX=v[0];var minY=v[1];var maxY=v[1];var minZ=v[2];var maxZ=v[2]
        for(i in 0 until v.size/3){val x=v[i*3];val y=v[i*3+1];val z=v[i*3+2];minX=minOf(minX,x);maxX=maxOf(maxX,x);minY=minOf(minY,y);maxY=maxOf(maxY,y);minZ=minOf(minZ,z);maxZ=maxOf(maxZ,z)}
        center=floatArrayOf((minX+maxX)/2,(minY+maxY)/2,(minZ+maxZ)/2);val dx=maxX-minX;val dy=maxY-minY;val dz=maxZ-minZ;radius=max(0.5f,sqrt(dx*dx+dy*dy+dz*dz)/2)}
    private fun directFloatBuffer(a:FloatArray)=ByteBuffer.allocateDirect(a.size*4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply{put(a);position(0)}
    private fun directIntBuffer(a:IntArray)=ByteBuffer.allocateDirect(a.size*4).order(ByteOrder.nativeOrder()).asIntBuffer().apply{put(a);position(0)}
    private fun createProgram(v:String,f:String):Int{fun shader(type:Int,src:String):Int{val s=GLES30.glCreateShader(type);GLES30.glShaderSource(s,src);GLES30.glCompileShader(s);val ok=IntArray(1);GLES30.glGetShaderiv(s,GLES30.GL_COMPILE_STATUS,ok,0);if(ok[0]==0)error(GLES30.glGetShaderInfoLog(s));return s};val vs=shader(GLES30.GL_VERTEX_SHADER,v);val fs=shader(GLES30.GL_FRAGMENT_SHADER,f);val p=GLES30.glCreateProgram();GLES30.glAttachShader(p,vs);GLES30.glAttachShader(p,fs);GLES30.glLinkProgram(p);return p}
    companion object { const val VS="#version 300 es\nin vec3 aPos; uniform mat4 uMvp; void main(){gl_Position=uMvp*vec4(aPos,1.0);}"; const val FS="#version 300 es\nprecision mediump float; uniform vec4 uColor; out vec4 frag; void main(){frag=uColor;}" }
}
