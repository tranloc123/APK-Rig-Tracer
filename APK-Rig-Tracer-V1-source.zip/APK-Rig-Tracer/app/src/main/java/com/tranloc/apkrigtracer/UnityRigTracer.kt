package com.tranloc.apkrigtracer

import io.github.deficuet.unitykt.UnityAssetManager
import io.github.deficuet.unitykt.classes.*
import io.github.deficuet.unitykt.pptr.safeGetObj
import java.io.File
import java.util.concurrent.CancellationException

object UnityRigTracer {
    fun trace(root: File, candidates: List<File>, cancelled: () -> Boolean = { false }): Pair<List<RigSnapshot>, List<String>> {
        val warnings = mutableListOf<String>()
        val rigs = mutableListOf<RigSnapshot>()
        UnityAssetManager.new(root, debugOutput = { msg ->
            if (msg.contains("error", true)) warnings += msg.take(300)
        }).use { manager ->
            candidates.distinctBy { it.absolutePath }.take(5000).forEach { f ->
                if (cancelled()) throw CancellationException("Đã hủy")
                if (f.length() > 1536L * 1024 * 1024) { warnings += "Bỏ qua file >1.5 GiB trong V1: ${f.name}"; return@forEach }
                runCatching { manager.loadFile(f) }.onFailure {
                    // Many files under StreamingAssets aren't serialized Unity files. Ignore them quietly.
                }
            }
            val renderers = manager.objectList.filterIsInstance<SkinnedMeshRenderer>()
            for (smr in renderers) {
                runCatching { buildSnapshot(smr) }
                    .onSuccess { if (it != null) rigs += it }
                    .onFailure { warnings += "Rig parse lỗi: ${it.message}" }
            }
        }
        if (rigs.isEmpty()) warnings += "Không tìm thấy SkinnedMeshRenderer có Mesh + bones trong dữ liệu Unity đã nạp."
        return rigs.distinctBy { it.source + "#" + it.name } to warnings.distinct().take(30)
    }

    private fun buildSnapshot(smr: SkinnedMeshRenderer): RigSnapshot? {
        val mesh = smr.mMesh.safeGetObj() ?: return null
        val go = smr.mGameObject.safeGetObj()
        val name = go?.mName?.takeIf { it.isNotBlank() } ?: mesh.mName.ifBlank { "Rig_${mesh.mPathID}" }
        val transforms = smr.mBones.mapNotNull { it.safeGetObj() }
        if (transforms.isEmpty()) return null
        val indexById = transforms.mapIndexed { i, t -> t.mPathID to i }.toMap()
        val bind = mesh.mBindPose
        val bones = transforms.mapIndexed { i, t ->
            val bgo = t.mGameObject.safeGetObj()
            val parentId = t.mFather.mPathID
            val inv = if (i < bind.size) FloatArray(16) { k ->
                val col = k / 4; val row = k % 4; bind[i][row, col]
            } else identity16()
            BoneSnapshot(
                name = bgo?.mName?.ifBlank { "Bone_$i" } ?: "Bone_$i",
                pathId = t.mPathID,
                parentIndex = indexById[parentId] ?: -1,
                tx = t.mLocalPosition.x, ty = t.mLocalPosition.y, tz = t.mLocalPosition.z,
                qx = t.mLocalRotation.a, qy = t.mLocalRotation.b, qz = t.mLocalRotation.c, qw = t.mLocalRotation.d,
                sx = t.mLocalScale.x, sy = t.mLocalScale.y, sz = t.mLocalScale.z,
                inverseBind = inv
            )
        }
        val v = mesh.mVertices
        val skin = mesh.mSkin
        val vertexCount = mesh.mVertexCount.coerceAtMost(v.size / 3)
        val jointIdx = IntArray(vertexCount * 4)
        val weights = FloatArray(vertexCount * 4)
        for (i in 0 until minOf(vertexCount, skin.size)) {
            val s = skin[i]
            for (j in 0 until 4) {
                jointIdx[i * 4 + j] = s.boneIndex.getOrElse(j) { 0 }.coerceIn(0, maxOf(0, bones.lastIndex))
                weights[i * 4 + j] = s.weight.getOrElse(j) { 0f }
            }
            val sum = (0..3).sumOf { weights[i * 4 + it].toDouble() }.toFloat()
            if (sum > 0f && kotlin.math.abs(sum - 1f) > 0.001f) for (j in 0..3) weights[i * 4 + j] /= sum
        }
        val idx = mesh.mIndices.map { it.toLong().toInt() }.toIntArray()
        val avatar = go?.mAnimator?.mAvatar?.safeGetObj()?.mName
        val animCount = go?.mAnimation?.mAnimations?.count { it.safeGetObj() != null } ?: 0
        val ws = mutableListOf<String>()
        if (bind.size != bones.size) ws += "Bind pose ${bind.size} != bones ${bones.size}"
        if (skin.size < vertexCount) ws += "Skin weights thiếu: ${skin.size}/$vertexCount vertex"
        return RigSnapshot(
            name, File(mesh.context.parent, mesh.context.name).path,
            v.copyOf(vertexCount * 3), mesh.mNormals,
            idx, jointIdx, weights, bones, avatar, animCount, ws
        )
    }

    private fun identity16() = FloatArray(16) { if (it % 5 == 0) 1f else 0f }
}
