package com.tranloc.apkrigtracer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.tranloc.apkrigtracer.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.CancellationException

class MainActivity: AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val allRigs=mutableListOf<RigSnapshot>()
    private val shown=mutableListOf<RigSnapshot>()
    private var selected=-1
    private var pendingExport:ByteArray?=null
    private var scanJob: Job? = null

    private val pickFile=registerForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)scanFile(uri)}
    private val pickFolder=registerForActivityResult(ActivityResultContracts.OpenDocumentTree()){uri->if(uri!=null)scanFolder(uri)}
    private val createGlb=registerForActivityResult(ActivityResultContracts.CreateDocument("model/gltf-binary")){uri->
        val data=pendingExport;pendingExport=null
        if(uri!=null&&data!=null) lifecycleScope.launch(Dispatchers.IO){
            runCatching{contentResolver.openOutputStream(uri,"w")!!.use{it.write(data)}}
                .onSuccess{withContext(Dispatchers.Main){toast("Đã lưu GLB")}}
                .onFailure{withContext(Dispatchers.Main){toast("Lưu thất bại: ${it.message}")}}
        }
    }

    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);b=ActivityMainBinding.inflate(layoutInflater);setContentView(b.root)
        b.pickFile.setOnClickListener{pickFile.launch(arrayOf("application/vnd.android.package-archive","application/zip","application/octet-stream","*/*"))}
        b.pickFolder.setOnClickListener{pickFolder.launch(null)}
        b.riggedOnly.setOnCheckedChangeListener{_,_->refreshList()}
        b.modelList.setOnItemClickListener{_,_,pos,_->selected=pos;b.status.text="Đã chọn: ${shown[pos].name}"}
        b.trace.setOnClickListener{selectedRig()?.let{showTrace(it)}?:toast("Chọn model trước")}
        b.preview.setOnClickListener{selectedRig()?.let{SessionStore.selectedRig=it;startActivity(Intent(this,PreviewActivity::class.java))}?:toast("Chọn model trước")}
        b.export.setOnClickListener{selectedRig()?.let{exportRig(it)}?:toast("Chọn model trước")}
        b.cancel.setOnClickListener{scanJob?.cancel(); b.status.text="Đã yêu cầu hủy…"}
    }

    private fun scanFile(uri:Uri)=runScan("Đang đọc file…"){InputMaterializer(this@MainActivity){scanJob?.isActive==false}.fromUri(uri)}
    private fun scanFolder(uri:Uri)=runScan("Đang sao chép thư mục…"){InputMaterializer(this@MainActivity){scanJob?.isActive==false}.fromTree(uri)}

    private fun runScan(initial:String,materialize:suspend()->InputMaterializer.Result){
        b.status.text=initial;setBusy(true);selected=-1;allRigs.clear();refreshList()
        scanJob=lifecycleScope.launch{
            try {
                val result=withContext(Dispatchers.IO){
                    val m=materialize();val detection=EngineDetector.detect(m.root)
                    val warnings=mutableListOf<String>();warnings+=m.warnings;warnings+=detection.warnings
                    val rigs=if(detection.engine=="Unity"){
                        val (r,w)=UnityRigTracer.trace(m.root,detection.unityFiles){scanJob?.isActive==false};warnings+=w;r
                    }else emptyList()
                    ScanSummary(detection.engine,detection.filesScanned,detection.unityFiles.size,warnings.distinct(),rigs)
                }
                allRigs+=result.rigs;refreshList()
                val msg="Engine: ${result.engine} | Files: ${result.filesScanned} | Unity candidates: ${result.unityCandidates} | Rigged models: ${result.rigs.count{it.isRigged}}"
                b.status.text=msg
                if(result.warnings.isNotEmpty()) AlertDialog.Builder(this@MainActivity).setTitle("Kết quả quét")
                    .setMessage(msg+"\n\n"+result.warnings.take(12).joinToString("\n• ",prefix="• ")).setPositiveButton("OK",null).show()
            } catch (_: CancellationException) { b.status.text="Đã hủy quét" }
              catch (t: Throwable) { b.status.text="Quét thất bại"; toast("Lỗi: ${t.message}") }
            finally { setBusy(false); scanJob=null }
        }
    }

    private fun refreshList(){
        shown.clear();shown+=if(b.riggedOnly.isChecked)allRigs.filter{it.isRigged}else allRigs
        val labels=shown.map{"${it.name}  •  ${it.boneCount} bones  •  ${it.vertexCount} vtx"}
        b.modelList.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,labels);selected=-1
    }
    private fun selectedRig():RigSnapshot?=shown.getOrNull(selected)
    private fun showTrace(r:RigSnapshot){
        val roots=r.bones.withIndex().filter{it.value.parentIndex<0}.joinToString{it.value.name}
        val bones=r.bones.take(80).mapIndexed{i,x->"${i.toString().padStart(3)}  ${"  ".repeat(depthOf(r,i).coerceAtMost(8))}${x.name}"}.joinToString("\n")
        val more=if(r.bones.size>80)"\n… +${r.bones.size-80} bones" else ""
        val warn=if(r.warnings.isEmpty())"Không" else r.warnings.joinToString("; ")
        AlertDialog.Builder(this).setTitle("Truy vết: ${r.name}").setMessage(
            "Source: ${r.source}\nMesh vertices: ${r.vertexCount}\nTriangles: ${r.indices.size/3}\nSkeleton: ${r.boneCount} bones\nRoot(s): $roots\nAvatar: ${r.avatarName?:"không thấy"}\nAnimation trực tiếp: ${r.animationCount}\nCảnh báo: $warn\n\nBONE TREE\n$bones$more"
        ).setPositiveButton("OK",null).show()
    }
    private fun depthOf(r:RigSnapshot,i:Int):Int{var d=0;var p=r.bones[i].parentIndex;val seen=HashSet<Int>();while(p in r.bones.indices&&seen.add(p)&&d<16){d++;p=r.bones[p].parentIndex};return d}
    private fun exportRig(r:RigSnapshot){
        if(r.vertexCount>1_500_000){toast("Model quá lớn (>1.5M vertex) cho export V1 trên điện thoại");return}
        setBusy(true);b.status.text="Đang đóng gói GLB…"
        lifecycleScope.launch{
            val res=withContext(Dispatchers.Default){runCatching{GlbWriter.write(r)}}
            setBusy(false);res.onSuccess{pendingExport=it;createGlb.launch(safeFileName(r.name)+".glb")}
                .onFailure{b.status.text="Export lỗi";toast("Export lỗi: ${it.message}")}
        }
    }
    private fun safeFileName(s:String)=s.replace(Regex("[^A-Za-z0-9._ -]"),"_").take(80).ifBlank{"model"}
    private fun setBusy(v:Boolean){b.pickFile.isEnabled=!v;b.pickFolder.isEnabled=!v;b.trace.isEnabled=!v;b.preview.isEnabled=!v;b.export.isEnabled=!v;b.cancel.isEnabled=v}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
}
