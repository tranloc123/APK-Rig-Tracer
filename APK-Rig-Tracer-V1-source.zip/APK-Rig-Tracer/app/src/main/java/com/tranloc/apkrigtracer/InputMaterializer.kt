package com.tranloc.apkrigtracer

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.CancellationException

/**
 * Copies user-selected inputs into an app-owned workspace. V2 preserves every file
 * and leaves all container discovery/extraction to UniversalScanner.
 */
class InputMaterializer(
    private val context: Context,
    private val cancelled: () -> Boolean = { false }
) {
    data class Result(val root: File, val warnings: List<String>)

    private val maxWorkspaceBytes = 10L * 1024 * 1024 * 1024
    private val maxEntries = 100_000

    fun fromUri(uri: Uri): Result {
        val workspace = freshWorkspace()
        val name = DocumentFile.fromSingleUri(context, uri)?.name ?: "input.bin"
        val original = File(workspace, safeName(name))
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "Không mở được file đã chọn" }
            FileOutputStream(original).use { output -> copyChecked(input, output, null) }
        }
        return Result(workspace, emptyList())
    }

    fun fromTree(uri: Uri): Result {
        val workspace = freshWorkspace()
        val root = DocumentFile.fromTreeUri(context, uri) ?: error("Không đọc được thư mục")
        val budget = Budget()

        fun walk(node: DocumentFile, outDir: File) {
            checkCancelled()
            budget.entries++
            if (budget.entries > maxEntries) error("Thư mục có quá nhiều mục (> $maxEntries)")
            if (node.isDirectory) {
                val dir = File(outDir, safeName(node.name ?: "dir")).apply { mkdirs() }
                node.listFiles().forEach { walk(it, dir) }
            } else if (node.isFile) {
                val target = File(outDir, safeName(node.name ?: "asset.bin"))
                context.contentResolver.openInputStream(node.uri).use { input ->
                    if (input != null) FileOutputStream(target).use { copyChecked(input, it, budget) }
                }
            }
        }

        root.listFiles().forEach { walk(it, workspace) }
        return Result(workspace, emptyList())
    }

    private data class Budget(var bytes: Long = 0, var entries: Int = 0)

    private fun freshWorkspace(): File {
        val base = File(context.cacheDir, "rigtrace_v2")
        base.deleteRecursively()
        base.mkdirs()
        return base
    }

    private fun copyChecked(input: InputStream, output: java.io.OutputStream, budget: Budget?) {
        val buf = ByteArray(1024 * 1024)
        while (true) {
            checkCancelled()
            val n = input.read(buf)
            if (n <= 0) break
            if (budget != null) {
                budget.bytes += n
                if (budget.bytes > maxWorkspaceBytes) error("Workspace vượt giới hạn 10 GiB của một phiên quét")
            }
            output.write(buf, 0, n)
        }
    }

    private fun checkCancelled() {
        if (cancelled()) throw CancellationException("Đã hủy")
    }

    private fun safeName(name: String): String = name
        .replace(Regex("[^A-Za-z0-9._ -]"), "_")
        .take(180)
        .ifBlank { "unnamed" }
}
